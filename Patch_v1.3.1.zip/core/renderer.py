import os
import subprocess
import re
import time

class VideoRenderer:
    def __init__(self, ffmpeg_path="ffmpeg", ffprobe_path="ffprobe"):
        self.ffmpeg_path = ffmpeg_path
        self.ffprobe_path = ffprobe_path
        self.is_running = False

    def log(self, callback, msg):
        if callback:
            callback(msg)
        else:
            print(msg)

    def get_video_duration(self, video_path):
        cmd = [
            self.ffprobe_path,
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            video_path
        ]
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                text=True
            )
            val = proc.stdout.strip()
            return float(val) if val else 0.0
        except Exception:
            return 0.0

    def get_video_dimensions(self, video_path):
        cmd = [
            self.ffprobe_path,
            "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height",
            "-of", "csv=p=0:s=x",
            video_path
        ]
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                text=True
            )
            res = proc.stdout.strip().split("x")
            if len(res) == 2:
                return int(res[0]), int(res[1])
        except Exception:
            pass
        return 1280, 720

    def escape_ffmpeg_path(self, path):
        escaped = path.replace('\\', '/')
        escaped = escaped.replace(':', '\\:')
        escaped = escaped.replace("'", "\\'")
        return f"'{escaped}'"

    def has_audio_stream(self, video_path):
        cmd = [
            self.ffprobe_path,
            "-v", "error",
            "-select_streams", "a:0",
            "-show_entries", "stream=codec_type",
            "-of", "csv=p=0",
            video_path
        ]
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                text=True
            )
            return bool(proc.stdout.strip())
        except Exception:
            return False

    def build_ffmpeg_command(self, video_path, tts_audio_path, output_path,
                             bgm_path=None, srt_path=None, blurs=None, logos=None,
                             orig_vol=0.1, tts_vol=1.0, bgm_vol=0.2,
                             codec="libx264", preset="medium", crf=23, 
                             sub_style=None, max_duration=None, log_cb=None, subtitles_list=None):
        hwaccel_args = []
        if codec in ["h264_nvenc", "hevc_nvenc"]:
            hwaccel_args = ["-hwaccel", "cuda"]

        inputs = hwaccel_args + ["-i", video_path]
        inputs += ["-i", tts_audio_path]
        
        bgm_idx = -1
        logo_idx_start = 2
        
        if bgm_path and os.path.exists(bgm_path):
            inputs += ["-i", bgm_path]
            bgm_idx = 2
            logo_idx_start = 3

        logo_inputs = []
        if logos:
            for logo in logos:
                logo_path = logo.get("path")
                if logo_path and os.path.exists(logo_path):
                    logo_inputs.append(logo)
                    inputs += ["-i", logo_path]

        v_dur = self.get_video_duration(video_path)
        a_dur = self.get_video_duration(tts_audio_path)

        v_filters = []
        a_filters = []
        v_label = "[0:v]"

        real_w, real_h = self.get_video_dimensions(video_path)

        target_v_dur = min(v_dur, max_duration) if (max_duration and max_duration > 0) else v_dur

        pts_scale = 1.0
        has_orig_audio = self.has_audio_stream(video_path)

        slowdown_subs = []
        if subtitles_list:
            for sub in subtitles_list:
                pts = getattr(sub, "video_pts_scale", 1.0)
                if pts > 1.001:
                    slowdown_subs.append(sub)

        if slowdown_subs and target_v_dur > 0:
            self.log(log_cb, f"🎬 [Làm Chậm Phân Đoạn Video] Đang áp dụng làm chậm video cho {len(slowdown_subs)} đoạn thoại để khớp 100% kịch bản...")
            segments = []
            curr_t = 0.0
            sorted_subs = sorted(subtitles_list, key=lambda s: getattr(s, "orig_start_sec", s.start.total_seconds()))
            
            for sub in sorted_subs:
                s_start = max(0.0, min(target_v_dur, getattr(sub, "orig_start_sec", sub.start.total_seconds())))
                s_end = max(s_start, min(target_v_dur, getattr(sub, "orig_end_sec", sub.end.total_seconds())))
                pts_scale_sub = getattr(sub, "video_pts_scale", 1.0)
                
                if s_start > curr_t + 0.01:
                    segments.append({"start": curr_t, "end": s_start, "pts_scale": 1.0})
                
                if s_end > s_start + 0.01:
                    segments.append({"start": s_start, "end": s_end, "pts_scale": pts_scale_sub})
                    curr_t = s_end
            
            if curr_t < target_v_dur - 0.01:
                segments.append({"start": curr_t, "end": target_v_dur, "pts_scale": 1.0})

            if segments:
                v_seg_labels = []
                a_seg_labels = []
                for idx, seg in enumerate(segments):
                    vl = f"[v_seg_{idx}]"
                    p_val = seg["pts_scale"]
                    v_filters.append(
                        f"[0:v]trim=start={seg['start']:.3f}:end={seg['end']:.3f},"
                        f"setpts={p_val:.4f}*(PTS-STARTPTS){vl}"
                    )
                    v_seg_labels.append(vl)

                    if has_orig_audio and orig_vol > 0.001:
                        al = f"[a_seg_{idx}]"
                        if p_val > 1.001:
                            atempo_val = max(0.5, min(1.0, 1.0 / p_val))
                            a_filters.append(
                                f"[0:a]atrim=start={seg['start']:.3f}:end={seg['end']:.3f},"
                                f"asetpts=PTS-STARTPTS,atempo={atempo_val:.4f}{al}"
                            )
                        else:
                            a_filters.append(
                                f"[0:a]atrim=start={seg['start']:.3f}:end={seg['end']:.3f},"
                                f"asetpts=PTS-STARTPTS{al}"
                            )
                        a_seg_labels.append(al)

                v_filters.append("".join(v_seg_labels) + f"concat=n={len(segments)}:v=1:a=0[v_slow]")
                v_label = "[v_slow]"

                if has_orig_audio and orig_vol > 0.001 and a_seg_labels:
                    a_filters.append("".join(a_seg_labels) + f"concat=n={len(segments)}:v=0:a=1,volume={orig_vol}[a_orig]")
        elif target_v_dur > 0 and a_dur > (target_v_dur + 0.1):
            exact_scale = a_dur / target_v_dur
            pts_scale = min(1.428, exact_scale)
            v_speed = 1.0 / pts_scale
            new_v_dur = target_v_dur * pts_scale
            extend_pct = ((new_v_dur - target_v_dur) / target_v_dur) * 100.0
            
            self.log(log_cb, f"🎬 [Làm Chậm Video Tự Động] Âm thanh ({a_dur:.2f}s) > Video ({target_v_dur:.2f}s) ➔ Tốc độ video: {v_speed:.2f}x (setpts={pts_scale:.4f}*PTS, Thời lượng video mới: {new_v_dur:.2f}s).")
            v_filters.append(f"{v_label}setpts={pts_scale:.4f}*PTS[v_slow]")
            v_label = "[v_slow]"

        if blurs:
            for idx, blur in enumerate(blurs):
                if "x" in blur and "y" in blur:
                    bx = max(1, min(real_w - 9, int(blur["x"])))
                    by = max(1, min(real_h - 9, int(blur["y"])))
                    bw = max(8, min(real_w - 1 - bx, int(blur["w"])))
                    bh = max(8, min(real_h - 1 - by, int(blur["h"])))
                else:
                    px = blur.get("pct_x", 0) / 100.0 if blur.get("pct_x", 0) > 1 else blur.get("pct_x", 0)
                    py = blur.get("pct_y", 0) / 100.0 if blur.get("pct_y", 0) > 1 else blur.get("pct_y", 0)
                    pw = blur.get("pct_w", 0) / 100.0 if blur.get("pct_w", 0) > 1 else blur.get("pct_w", 0)
                    ph = blur.get("pct_h", 0) / 100.0 if blur.get("pct_h", 0) > 1 else blur.get("pct_h", 0)
                    bx = max(1, min(real_w - 9, int(real_w * px)))
                    by = max(1, min(real_h - 9, int(real_h * py)))
                    bw = max(8, min(real_w - 1 - bx, int(real_w * pw)))
                    bh = max(8, min(real_h - 1 - by, int(real_h * ph)))
                
                bw = bw - (bw % 2)
                bh = bh - (bh % 2)
                if bw < 8: bw = 8
                if bh < 8: bh = 8
                if bx + bw >= real_w:
                    bx = max(1, real_w - 1 - bw)
                if by + bh >= real_h:
                    by = max(1, real_h - 1 - bh)

                out_label = f"[v_blur_{idx}]"
                b_type = blur.get("type", "delogo")

                if b_type == "boxblur":
                    # Gaussian blur: split → crop → gblur → overlay lại đúng vị trí
                    # Không dùng alphamerge (yêu cầu alpha channel, video thường không có)
                    v_filters.append(
                        f"{v_label}split=2[v_main_{idx}][v_tmp_{idx}];"
                        f"[v_tmp_{idx}]crop={bw}:{bh}:{bx}:{by},gblur=sigma=25[v_blurred_{idx}];"
                        f"[v_main_{idx}][v_blurred_{idx}]overlay={bx}:{by}{out_label}"
                    )
                else:
                    # Delogo Inpainting: Lấy màu nền xung quanh lấp vào vùng chọn,
                    # hòa trộn tự nhiên như nội dung gốc (tốt hơn blur đơn thuần)
                    v_filters.append(f"{v_label}delogo=x={bx}:y={by}:w={bw}:h={bh}{out_label}")

                v_label = out_label


        for idx, logo in enumerate(logo_inputs):
            curr_logo_idx = logo_idx_start + idx
            logo_scaled_label = f"[logo_scale_{idx}]"
            
            if "x" in logo and "y" in logo:
                lx = max(0, min(real_w - 4, int(logo["x"])))
                ly = max(0, min(real_h - 4, int(logo["y"])))
                lw = max(4, min(real_w - lx, int(logo["w"])))
                lh = max(4, min(real_h - ly, int(logo["h"])))
                lw = lw - (lw % 2)
                lh = lh - (lh % 2)
                v_filters.append(f"[{curr_logo_idx}:v]scale={lw}:{lh}{logo_scaled_label}")
                overlay_expr = f"{lx}:{ly}"
            else:
                px = logo.get("pct_x", 0) / 100.0 if logo.get("pct_x", 0) > 1 else logo.get("pct_x", 0)
                py = logo.get("pct_y", 0) / 100.0 if logo.get("pct_y", 0) > 1 else logo.get("pct_y", 0)
                scale = logo.get("scale", 100) / 100.0
                v_filters.append(f"[{curr_logo_idx}:v]scale=iw*{scale}:ih*{scale}{logo_scaled_label}")
                overlay_expr = f"iw*{px}:ih*{py}"

            out_label = f"[v_logo_{idx}]"
            v_filters.append(f"{v_label}{logo_scaled_label}overlay={overlay_expr}{out_label}")
            v_label = out_label

        if srt_path and os.path.exists(srt_path):
            escaped_srt = self.escape_ffmpeg_path(srt_path)
            
            style_str = ""
            if sub_style:
                font = sub_style.get("font", "Arial")
                size = sub_style.get("size", 24)
                color = sub_style.get("color", "#FFFFFF")
                outline = sub_style.get("outline_color", "#000000")
                bg_enabled = sub_style.get("bg_enabled", False)
                bold = sub_style.get("bold", True)
                italic = sub_style.get("italic", True)
                shadow = sub_style.get("shadow", True)
                outline_w = sub_style.get("outline_width", 3.5)
                
                def hex_to_ass(hex_color):
                    h = hex_color.lstrip("#")
                    if len(h) == 6:
                        r, g, b = h[0:2], h[2:4], h[4:6]
                        return f"&H00{b}{g}{r}"
                    return "&H00FFFFFF"

                pri_col = hex_to_ass(color)
                out_col = hex_to_ass(outline)
                
                bold_val = 1 if bold else 0
                italic_val = 1 if italic else 0
                shadow_val = 2 if shadow else 0

                style_str = f":force_style='Fontname={font},Fontsize={size},PrimaryColour={pri_col},OutlineColour={out_col},PlayResX={real_w},PlayResY={real_h},Bold={bold_val},Italic={italic_val}"
                if bg_enabled:
                    style_str += f",BorderStyle=3,Outline={outline_w},Shadow={shadow_val},BackColour=&H80000000"
                else:
                    # Ảnh 1: Tùy chỉnh In đậm, Nghiêng, Viền đen đậm, Bóng đổ nhẹ (Tùy chọn linh hoạt)
                    style_str += f",BorderStyle=1,Outline={outline_w},Shadow={shadow_val},BackColour=&H80000000"
                
                pct_y = sub_style.get("pct_y", 85.0)
                
                if pct_y < 50.0:
                    margin_v = max(5, int((pct_y / 100.0) * real_h - size / 2.0))
                    style_str += f",Alignment=8,MarginV={margin_v}'"
                else:
                    margin_v = max(5, int(((100.0 - pct_y) / 100.0) * real_h - size / 2.0))
                    style_str += f",Alignment=2,MarginV={margin_v}'"

            import sys
            if getattr(sys, 'frozen', False):
                fonts_dir = getattr(sys, '_MEIPASS', os.getcwd())
            else:
                fonts_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            escaped_fontsdir = os.path.abspath(fonts_dir).replace('\\', '/')
            escaped_fontsdir = escaped_fontsdir.replace(':', '\\:')

            out_label = "[v_sub]"
            v_filters.append(f"{v_label}subtitles={escaped_srt}:fontsdir='{escaped_fontsdir}':original_size={real_w}x{real_h}{style_str}{out_label}")
            v_label = out_label

        # Ensure video width & height are always even numbers (divisible by 2) for libx264 / H.264
        out_label = "[v_even]"
        v_filters.append(f"{v_label}scale=ceil(iw/2)*2:ceil(ih/2)*2{out_label}")
        v_label = out_label

        has_orig_audio = self.has_audio_stream(video_path)

        if has_orig_audio and orig_vol > 0.001:
            if not any("[a_orig]" in f for f in a_filters):
                if pts_scale > 1.001:
                    atempo_val = max(0.5, min(1.0, 1.0 / pts_scale))
                    a_filters.append(f"[0:a]atempo={atempo_val:.4f},volume={orig_vol}[a_orig]")
                else:
                    a_filters.append(f"[0:a]volume={orig_vol}[a_orig]")

        # BUG FIX: Khi max_duration > 0 (video mẫu), trim audio TTS để không vượt quá thời lượng video
        if max_duration and max_duration > 0:
            a_filters.append(f"[1:a]atrim=0:{max_duration:.2f},asetpts=PTS-STARTPTS,volume={tts_vol}[a_tts]")
        else:
            a_filters.append(f"[1:a]volume={tts_vol}[a_tts]")
        
        if bgm_idx != -1:
            # VideoLingo #8: BGM Sidechain Auto-Ducking - Giảm âm lượng nhạc nền tự động khi có giọng đọc TTS
            a_filters.append(f"[{bgm_idx}:a]volume={bgm_vol}[a_bgm_raw]")
            a_filters.append("[a_bgm_raw][a_tts]sidechaincompress=threshold=0.08:ratio=4:attack=20:release=300[a_bgm]")
            
            if has_orig_audio and orig_vol > 0.001:
                a_filters.append("[a_orig][a_tts][a_bgm]amix=inputs=3:duration=longest:dropout_transition=0:normalize=0,apad,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11[a_final]")
            else:
                a_filters.append("[a_tts][a_bgm]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0,apad,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11[a_final]")
        else:
            if has_orig_audio and orig_vol > 0.001:
                a_filters.append("[a_orig][a_tts]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0,apad,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11[a_final]")
            else:
                a_filters.append("[a_tts]apad,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11[a_final]")

        cmd = [self.ffmpeg_path, "-y"] + inputs
        filter_complex_parts = v_filters + a_filters
        filter_complex_str = ";".join(filter_complex_parts)
        
        cmd += ["-filter_complex", filter_complex_str]
        cmd += ["-map", v_label, "-map", "[a_final]"]
        
        if codec == "h264_nvenc":
            nv_preset_map = {
                "ultrafast": "p1",
                "superfast": "p2",
                "veryfast": "p3",
                "faster": "p4",
                "fast": "p4",
                "medium": "p5",
                "slow": "p7"
            }
            nv_preset = nv_preset_map.get(preset, "p4")
            cmd += ["-c:v", "h264_nvenc", "-profile:v", "high", "-preset", nv_preset, "-pix_fmt", "yuv420p", "-rc", "constqp", "-qp", "19", "-r", "30", "-fps_mode", "cfr"]
        elif codec == "hevc_nvenc":
            nv_preset_map = {
                "ultrafast": "p1",
                "superfast": "p2",
                "veryfast": "p3",
                "faster": "p4",
                "fast": "p4",
                "medium": "p5",
                "slow": "p7"
            }
            nv_preset = nv_preset_map.get(preset, "p4")
            cmd += ["-c:v", "hevc_nvenc", "-preset", nv_preset, "-pix_fmt", "yuv420p", "-r", "30", "-fps_mode", "cfr"]
        else:
            cmd += ["-c:v", "libx264", "-profile:v", "high", "-preset", preset if preset else "slow", "-crf", "18", "-pix_fmt", "yuv420p", "-r", "30", "-fps_mode", "cfr"]
            
        cmd += ["-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "192k", "-shortest"]
        
        if max_duration and max_duration > 0:
            cmd += ["-t", f"{max_duration:.2f}"]

        cmd.append(output_path)
        return cmd

    def create_slowed_video_from_segments(self, video_path, subtitles_list, max_duration=None, log_cb=None):
        import tempfile, shutil
        v_dur = self.get_video_duration(video_path)
        if v_dur <= 0:
            return None

        target_v_dur = min(v_dur, max_duration) if (max_duration and max_duration > 0) else v_dur

        sorted_subs = sorted(subtitles_list, key=lambda s: getattr(s, "orig_start_sec", s.start.total_seconds()))
        segments = []
        curr_t = 0.0

        for sub in sorted_subs:
            s_start = max(0.0, min(target_v_dur, getattr(sub, "orig_start_sec", sub.start.total_seconds())))
            s_end = max(s_start, min(target_v_dur, getattr(sub, "orig_end_sec", sub.end.total_seconds())))
            pts_scale = getattr(sub, "video_pts_scale", 1.0)

            if s_start > curr_t + 0.01:
                segments.append({"start": curr_t, "end": s_start, "pts_scale": 1.0})
            
            if s_end > s_start + 0.01:
                segments.append({"start": s_start, "end": s_end, "pts_scale": pts_scale})
                curr_t = s_end

        if curr_t < target_v_dur - 0.01:
            segments.append({"start": curr_t, "end": target_v_dur, "pts_scale": 1.0})

        if not segments:
            return None

        temp_dir = tempfile.mkdtemp(prefix="dsub_video_segments_")
        segment_files = []
        has_orig_audio = self.has_audio_stream(video_path)

        try:
            for idx, seg in enumerate(segments):
                seg_file = os.path.join(temp_dir, f"seg_{idx:03d}.mp4")
                p_val = seg["pts_scale"]
                dur = max(0.05, seg["end"] - seg["start"])
                
                cmd = [
                    self.ffmpeg_path, "-y",
                    "-i", video_path,
                    "-ss", f"{seg['start']:.3f}",
                    "-t", f"{dur:.3f}"
                ]

                vf_str = f"setpts={p_val:.4f}*(PTS-STARTPTS),scale=ceil(iw/2)*2:ceil(ih/2)*2"
                cmd += ["-vf", vf_str]

                if has_orig_audio:
                    if p_val > 1.001:
                        atempo_val = max(0.5, min(1.0, 1.0 / p_val))
                        cmd += ["-af", f"atempo={atempo_val:.4f}"]
                    cmd += ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "18", "-r", "30", "-c:a", "aac", "-ar", "44100", seg_file]
                else:
                    cmd += ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "18", "-r", "30", "-an", seg_file]
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                )
                
                if os.path.exists(seg_file) and os.path.getsize(seg_file) > 0:
                    segment_files.append(seg_file)
                else:
                    # FALLBACK RETRY (Báo cáo v3 Bug 2 Fix):
                    # Nếu phân đoạn làm chậm thất bại, thử lại cắt phân đoạn nguyên tốc độ gốc để không bị đứt quãng timeline video
                    self.log(log_cb, f"⚠️ Đoạn {idx+1} làm chậm thất bại ({seg['start']:.2f}s–{seg['end']:.2f}s) → Thử lại tốc độ gốc...")
                    fallback_cmd = [
                        self.ffmpeg_path, "-y",
                        "-i", video_path,
                        "-ss", f"{seg['start']:.3f}",
                        "-t", f"{dur:.3f}",
                        "-vf", "scale=ceil(iw/2)*2:ceil(ih/2)*2",
                        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "18", "-r", "30"
                    ]
                    if has_orig_audio:
                        fallback_cmd += ["-c:a", "aac", "-ar", "44100", seg_file]
                    else:
                        fallback_cmd += ["-an", seg_file]
                    
                    subprocess.run(
                        fallback_cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                    )
                    if os.path.exists(seg_file) and os.path.getsize(seg_file) > 0:
                        segment_files.append(seg_file)
                    else:
                        self.log(log_cb, f"❌ Không thể tạo đoạn {idx+1} ({seg['start']:.2f}s–{seg['end']:.2f}s). Bỏ qua.")

            if not segment_files:
                return None

            concat_txt = os.path.join(temp_dir, "concat.txt")
            with open(concat_txt, "w", encoding="utf-8") as f:
                for sf in segment_files:
                    escaped_f = sf.replace("\\", "/")
                    f.write(f"file '{escaped_f}'\n")

            merged_slowed_video = os.path.join(tempfile.gettempdir(), f"slowed_video_{int(time.time())}.mp4")
            concat_cmd = [
                self.ffmpeg_path, "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", concat_txt,
                "-c", "copy",
                merged_slowed_video
            ]

            proc = subprocess.run(
                concat_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )

            if os.path.exists(merged_slowed_video) and os.path.getsize(merged_slowed_video) > 0:
                self.log(log_cb, f"✅ Chia & làm chậm hoàn tất — {len(segment_files)} đoạn video đã xử lý.")
                return merged_slowed_video
        except Exception as e:
            self.log(log_cb, f"❌ Lỗi chia phân đoạn video: {e}")
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

        return None

    def render_video(self, video_path, tts_audio_path, output_path,
                     bgm_path=None, srt_path=None, blurs=None, logos=None,
                     orig_vol=0.1, tts_vol=1.0, bgm_vol=0.2,
                     codec="libx264", preset="medium", crf=23, 
                     sub_style=None, max_duration=None, log_cb=None, progress_cb=None,
                     subtitles_list=None):
        self.is_running = True
        
        if os.path.exists(output_path):
            try:
                with open(output_path, "r+b"):
                    pass
            except Exception:
                self.log(log_cb, f"❌ File xuất '{os.path.basename(output_path)}' đang bị khóa bởi phần mềm phát video.")
                self.log(log_cb, "   → Vui lòng đóng trình phát video (Media Player / Movies & TV) rồi thử lại.")
                return False

        v_dur = self.get_video_duration(video_path)
        a_dur = self.get_video_duration(tts_audio_path)
        
        # TỰ ĐỘNG CHIA NHỎ PHÂN ĐOẠN VIDEO THÀNH CÁC FILE ĐOẠN ĐỘC LẬP & LÀM CHẬM TRƯỚC KHI RENDER
        effective_video_path = video_path
        subtitles_list_for_build = subtitles_list

        slowdown_subs = [s for s in (subtitles_list or []) if getattr(s, "video_pts_scale", 1.0) > 1.001]
        if slowdown_subs and v_dur > 0:
            self.log(log_cb, f"✂️ Chia nhỏ & làm chậm {len(slowdown_subs)} đoạn thoại...")
            slowed_video = self.create_slowed_video_from_segments(
                video_path=video_path,
                subtitles_list=subtitles_list,
                max_duration=max_duration,
                log_cb=log_cb
            )
            if slowed_video and os.path.exists(slowed_video):
                effective_video_path = slowed_video
                subtitles_list_for_build = None
                # Recalculate v_dur from effective_video_path after pre-slow for accurate progress %
                v_dur = self.get_video_duration(effective_video_path)

        duration = max(v_dur, a_dur)
        if duration == 0.0:
            duration = 100.0
            
        if max_duration and max_duration > 0:
            duration = min(duration, max_duration)
            self.log(log_cb, f"🎬 Chế độ Mẫu — Giới hạn xuất đúng {max_duration:.1f}s.")

        self.log(log_cb, f"📐 Video gốc: {v_dur:.2f}s  |  Audio thuyết minh: {a_dur:.2f}s")
        self.log(log_cb, "⚙️  Đang khởi tạo bộ lọc FFmpeg...")

        cmd = self.build_ffmpeg_command(
            effective_video_path, tts_audio_path, output_path,
            bgm_path, srt_path, blurs, logos,
            orig_vol, tts_vol, bgm_vol,
            codec, preset, crf, sub_style, max_duration=max_duration, log_cb=log_cb,
            subtitles_list=subtitles_list_for_build
        )
        
        self.log(log_cb, f"▶  FFmpeg: {' '.join(cmd[:6])}...")

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.PIPE,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            text=True,
            encoding='utf-8',
            errors='ignore'
        )

        time_pattern = re.compile(r'time=(\d{2}):(\d{2}):(\d{2})\.(\d{2})')
        last_output_time = time.time()
        err_messages = []

        while self.is_running:
            line = proc.stdout.readline()
            if not line:
                if proc.poll() is not None:
                    break
                # Tránh treo nếu không nhận được output mới trong 60s
                if time.time() - last_output_time > 60:
                    self.log(log_cb, "❌ FFmpeg không phản hồi quá 180s → Tự động dừng render!")
                    try:
                        proc.kill()
                    except Exception:
                        pass
                    return False
                time.sleep(0.1)
                continue
            
            last_output_time = time.time()
            line_str = line.strip()
            if line_str and not line_str.startswith("frame=") and not line_str.startswith("size="):
                err_messages.append(line_str)

            match = time_pattern.search(line)
            if match:
                hours, minutes, seconds, hundredths = map(int, match.groups())
                current_time = hours * 3600 + minutes * 60 + seconds + hundredths / 100.0
                percent = int(min(current_time / duration * 100, 99))  # Giữ 99% cho đến khi thực sự xong
                if progress_cb:
                    progress_cb(percent)

        # Chờ process thực sự kết thúc, tối đa 30s
        try:
            proc.wait(timeout=30)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

        if not self.is_running:
            try:
                proc.kill()
            except Exception:
                pass
            self.log(log_cb, "⏹  Render đã bị hủy.")
            return False

        if proc.returncode == 0:
            # Kiểm tra file output thực sự tồn tại và có nội dung
            if os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
                self.log(log_cb, f"🎉 Render hoàn tất → {os.path.basename(output_path)}")
                if progress_cb:
                    progress_cb(100)
                return True
            else:
                self.log(log_cb, "❌ FFmpeg báo thành công nhưng file output không tồn tại hoặc rỗng!")
                self.log(log_cb, "   → Kiểm tra lại đường dẫn lưu và dung lượng ổ đĩa.")
                return False
        else:
            if err_messages:
                last_errs = "\n".join(err_messages[-8:])
                self.log(log_cb, f"❌ Chi tiết lỗi FFmpeg:\n{last_errs}")
            self.log(log_cb, f"❌ Render thất bại — mã lỗi FFmpeg: {proc.returncode}")
            return False
