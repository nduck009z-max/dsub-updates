import sys
import os
import shutil
import zipfile
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox, 
                             QProgressBar, QTextEdit, QFrame, QGroupBox)
from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices, QIcon

DARK_STYLE = """
QMainWindow {
    background-color: #0f172a;
    color: #f8fafc;
    font-family: 'Segoe UI', Arial, sans-serif;
}
QFrame#HeaderFrame {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1e1b4b, stop:1 #0f172a);
    border-bottom: 1px solid #334155;
    padding: 12px;
}
QGroupBox {
    font-weight: bold;
    color: #38bdf8;
    border: 1px solid #334155;
    border-radius: 8px;
    margin-top: 8px;
    padding: 10px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
}
QLineEdit {
    background-color: #020617;
    color: #f8fafc;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 8px;
    font-size: 12px;
}
QPushButton {
    font-weight: bold;
    font-size: 12px;
    border-radius: 6px;
    padding: 8px 16px;
    border: none;
}
QPushButton#BtnBrowse {
    background-color: #334155;
    color: #f8fafc;
}
QPushButton#BtnBrowse:hover {
    background-color: #475569;
}
QPushButton#BtnUpdate {
    background-color: #059669;
    color: #ffffff;
    font-size: 13px;
    padding: 10px 20px;
}
QPushButton#BtnUpdate:hover {
    background-color: #10b981;
}
QPushButton#BtnUpdate:disabled {
    background-color: #334155;
    color: #64748b;
}
QProgressBar {
    background-color: #020617;
    border: 1px solid #334155;
    border-radius: 6px;
    text-align: center;
    color: #f8fafc;
}
QProgressBar::chunk {
    background-color: #059669;
    border-radius: 5px;
}
QTextEdit {
    background-color: #020617;
    color: #38bdf8;
    font-family: monospace;
    font-size: 11px;
    border: 1px solid #1e293b;
    border-radius: 6px;
    padding: 6px;
}
"""

class UpdateWorker(QThread):
    log_signal = Signal(str)
    progress_signal = Signal(int)
    finished_signal = Signal(bool, str)

    def __init__(self, target_dir, patch_source):
        super().__init__()
        self.target_dir = target_dir
        self.patch_source = patch_source

    def close_running_processes(self):
        if os.name == "nt":
            import subprocess
            procs = ["DSub_v1.3.exe", "DSub_v1.2.exe", "ffmpeg.exe", "piper.exe", "VideoSubFinderWXW.exe"]
            for p_name in procs:
                try:
                    subprocess.run(
                        ["taskkill", "/F", "/IM", p_name],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        creationflags=subprocess.CREATE_NO_WINDOW
                    )
                except Exception:
                    pass

    def safe_copy_file(self, src_f, dst_f):
        src_abs = os.path.normpath(os.path.abspath(src_f))
        dst_abs = os.path.normpath(os.path.abspath(dst_f))

        # Nếu file nguồn và file đích là cùng 1 file trên đĩa -> Không cần copy
        if src_abs == dst_abs:
            return True

        if not os.path.exists(src_abs):
            raise Exception(f"Không tìm thấy file nguồn cập nhật: '{os.path.basename(src_f)}'")

        os.makedirs(os.path.dirname(dst_abs), exist_ok=True)
        try:
            shutil.copy2(src_abs, dst_abs)
            return True
        except Exception:
            # Nếu file bị khóa (WinError 32), thử đổi tên tạm thời rồi ghi đè
            old_tmp = dst_abs + ".old_tmp"
            renamed = False
            try:
                if os.path.exists(old_tmp):
                    try: os.remove(old_tmp)
                    except Exception: pass
                if os.path.exists(dst_abs):
                    os.rename(dst_abs, old_tmp)
                    renamed = True
                shutil.copy2(src_abs, dst_abs)
                if os.path.exists(old_tmp):
                    try: os.remove(old_tmp)
                    except Exception: pass
                return True
            except Exception as err:
                if renamed and not os.path.exists(dst_abs) and os.path.exists(old_tmp):
                    try: os.rename(old_tmp, dst_abs)
                    except Exception: pass
                raise Exception(f"Lỗi ghi đè file '{os.path.basename(dst_f)}': {err}")

    def run(self):
        try:
            self.log_signal.emit("🔍 Đang kiểm tra thư mục cài đặt...")
            if not os.path.exists(self.target_dir):
                self.finished_signal.emit(False, "Thư mục phần mềm đích không tồn tại!")
                return

            self.log_signal.emit("🛡️ Đang đóng các tiến trình DSub đang chạy ngầm...")
            self.close_running_processes()
            import time
            time.sleep(0.5)

            self.progress_signal.emit(10)
            self.log_signal.emit(f"📁 Thư mục cài đặt: {self.target_dir}")

            # Backup client user configs if exists
            config_backup = {}
            for cfg_file in ["config.json", "ocr_roi.json", "config_effects.json", "config_render.json"]:
                cfg_path = os.path.join(self.target_dir, cfg_file)
                if os.path.exists(cfg_path):
                    try:
                        with open(cfg_path, "r", encoding="utf-8") as f:
                            config_backup[cfg_file] = f.read()
                    except Exception:
                        pass

            self.progress_signal.emit(30)

            # Apply patch
            if self.patch_source.endswith(".zip") and os.path.isfile(self.patch_source):
                self.log_signal.emit("📦 Đang giải nén gói cập nhật (.zip)...")
                with zipfile.ZipFile(self.patch_source, 'r') as zip_ref:
                    target_dir_abs = os.path.abspath(self.target_dir)
                    for member in zip_ref.infolist():
                        # Anti Zip-Slip protection: ensure extracted target path stays inside target_dir
                        target_file_path = os.path.abspath(os.path.join(self.target_dir, member.filename))
                        if not target_file_path.startswith(target_dir_abs):
                            self.log_signal.emit(f"  ⚠️ Bỏ qua file nghi vấn Zip-Slip: {member.filename}")
                            continue

                        if member.is_dir():
                            os.makedirs(target_file_path, exist_ok=True)
                        else:
                            extracted_path = zip_ref.extract(member, self.target_dir)
            elif os.path.isdir(self.patch_source):
                self.log_signal.emit("📂 Đang chép đè các file cập nhật mới...")
                for root, dirs, files in os.walk(self.patch_source):
                    rel_path = os.path.relpath(root, self.patch_source)
                    dest_path = os.path.join(self.target_dir, rel_path) if rel_path != "." else self.target_dir
                    os.makedirs(dest_path, exist_ok=True)
                    for f in files:
                        src_f = os.path.join(root, f)
                        dst_f = os.path.join(dest_path, f)
                        try:
                            self.safe_copy_file(src_f, dst_f)
                            self.log_signal.emit(f"  └─ Đã cập nhật: {f}")
                        except Exception as copy_err:
                            self.log_signal.emit(f"  ⚠️ Bỏ qua file: {f} ({copy_err})")
            elif os.path.isfile(self.patch_source) and self.patch_source.endswith(".exe"):
                self.log_signal.emit(f"🚀 Đang cập nhật file thực thi: {os.path.basename(self.patch_source)}")
                dst_exe = os.path.join(self.target_dir, os.path.basename(self.patch_source))
                self.safe_copy_file(self.patch_source, dst_exe)
                self.log_signal.emit(f"  └─ Cập nhật thành công: {os.path.basename(self.patch_source)}")

            self.progress_signal.emit(70)

            # Restore config files
            if config_backup:
                self.log_signal.emit("🔒 Đang khôi phục cài đặt tài khoản & cấu hình của bạn...")
                for cfg_file, content in config_backup.items():
                    cfg_path = os.path.join(self.target_dir, cfg_file)
                    try:
                        with open(cfg_path, "w", encoding="utf-8") as f:
                            f.write(content)
                    except Exception:
                        pass

            self.progress_signal.emit(100)
            self.log_signal.emit("\n🎉 CẬP NHẬT HOÀN TẤT SUÔN SẺ 100%!")
            self.finished_signal.emit(True, "Đã cập nhật thành công!")
        except Exception as e:
            self.log_signal.emit(f"❌ Cập nhật thất bại: {e}")
            self.finished_signal.emit(False, str(e))


class UpdaterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DSub - Công Cụ Cập Nhật Tự Động (Auto-Updater)")
        self.setFixedSize(540, 480)
        self.setStyleSheet(DARK_STYLE)
        self.init_ui()

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(10)

        # Header
        header = QFrame()
        header.setObjectName("HeaderFrame")
        h_layout = QVBoxLayout(header)
        h_layout.setContentsMargins(16, 12, 16, 12)
        lbl_title = QLabel("🚀 DSUB AUTO-UPDATER")
        lbl_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #38bdf8;")
        lbl_sub = QLabel("Công cụ cập nhật nhanh phiên bản DSub không cần tải lại toàn bộ file nặng")
        lbl_sub.setStyleSheet("font-size: 12px; color: #94a3b8;")
        h_layout.addWidget(lbl_title)
        h_layout.addWidget(lbl_sub)
        main_layout.addWidget(header)

        # Content area
        content_box = QVBoxLayout()
        content_box.setContentsMargins(16, 8, 16, 16)
        content_box.setSpacing(12)

        # Group 1: Target Folder Selection
        group_target = QGroupBox("1. Thư mục cài đặt phần mềm DSub trên máy")
        g1_layout = QHBoxLayout(group_target)
        self.txt_target = QLineEdit()
        auto_dir = self.auto_detect_dsub_folder()
        self.txt_target.setText(auto_dir)
        btn_browse_target = QPushButton("📁 Chọn Thư Mục")
        btn_browse_target.setObjectName("BtnBrowse")
        btn_browse_target.clicked.connect(self.browse_target_folder)
        g1_layout.addWidget(self.txt_target)
        g1_layout.addWidget(btn_browse_target)
        content_box.addWidget(group_target)

        # Group 2: Patch Source Selection
        group_patch = QGroupBox("2. Gói cập nhật (File .zip / .exe hoặc thư mục Patch)")
        g2_layout = QHBoxLayout(group_patch)
        self.txt_patch = QLineEdit()
        auto_patch = self.auto_detect_patch_file()
        self.txt_patch.setText(auto_patch)
        btn_browse_patch = QPushButton("📦 Chọn Gói Patch")
        btn_browse_patch.setObjectName("BtnBrowse")
        btn_browse_patch.clicked.connect(self.browse_patch_source)
        g2_layout.addWidget(self.txt_patch)
        g2_layout.addWidget(btn_browse_patch)
        content_box.addWidget(group_patch)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        content_box.addWidget(self.progress_bar)

        # Logs area
        self.txt_logs = QTextEdit()
        self.txt_logs.setReadOnly(True)
        self.txt_logs.setMinimumHeight(110)
        content_box.addWidget(self.txt_logs)

        # Update button
        self.btn_update = QPushButton("⚡ TIẾN HÀNH CẬP NHẬT NGAY")
        self.btn_update.setObjectName("BtnUpdate")
        self.btn_update.setCursor(Qt.PointingHandCursor)
        self.btn_update.clicked.connect(self.start_update)
        content_box.addWidget(self.btn_update)

        main_layout.addLayout(content_box)

    def auto_detect_dsub_folder(self):
        curr = os.getcwd()
        if os.path.exists(os.path.join(curr, "main.py")) or os.path.exists(os.path.join(curr, "DSub_v1.3.exe")) or os.path.exists(os.path.join(curr, "DSub_v1.2.exe")):
            return curr
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        possible = [os.path.join(desktop, "Dsub Tool"), os.path.join(desktop, "Dsub_v1.2"), os.path.join(desktop, "REUP TOOL")]
        for p in possible:
            if os.path.exists(p):
                return p
        return curr

    def auto_detect_patch_file(self):
        curr = os.getcwd()
        for f in os.listdir(curr):
            if f.endswith(".zip") or f.endswith(".patch") or f.startswith("DSub_v"):
                return os.path.join(curr, f)
        return curr

    def browse_target_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Chọn thư mục cài đặt DSub", self.txt_target.text() or os.getcwd())
        if d:
            self.txt_target.setText(d)

    def browse_patch_source(self):
        f, _ = QFileDialog.getOpenFileName(self, "Chọn gói cập nhật Patch (.zip / .exe)", self.txt_patch.text() or os.getcwd(), "Gói Cập Nhật (*.zip *.exe *.patch);;Tất cả (*.*)")
        if f:
            self.txt_patch.setText(f)

    def log(self, text):
        self.txt_logs.append(text)

    def start_update(self):
        target = self.txt_target.text().strip()
        patch = self.txt_patch.text().strip()

        if not target or not os.path.exists(target):
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng chọn đúng thư mục cài đặt DSub trên máy!")
            return

        if not patch or not os.path.exists(patch):
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng chọn đúng gói cập nhật Patch (.zip / .exe)!")
            return

        self.btn_update.setEnabled(False)
        self.progress_bar.setValue(0)
        self.txt_logs.clear()
        self.log(f"🚀 Bắt đầu tiến trình cập nhật DSub...")

        self.worker = UpdateWorker(target, patch)
        self.worker.log_signal.connect(self.log)
        self.worker.progress_signal.connect(self.progress_bar.setValue)
        
        def on_finished(success, msg):
            self.btn_update.setEnabled(True)
            if success:
                QMessageBox.information(self, "Cập Nhật Thành Công", f"🎉 Đã cập nhật phần mềm DSub thành công!\n\nBạn có thể mở phần mềm để sử dụng phiên bản mới nhất ngay bây giờ.")
            else:
                QMessageBox.critical(self, "Lỗi Cập Nhật", f"❌ Cập nhật thất bại:\n{msg}")

        self.worker.finished_signal.connect(on_finished)
        self.worker.start()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = UpdaterWindow()
    w.show()
    sys.exit(app.exec())
