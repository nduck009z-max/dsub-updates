import os
import json
import re
import subprocess
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QCheckBox, QComboBox, QSpinBox, QDoubleSpinBox, QSlider, 
                             QFileDialog, QMessageBox, QGroupBox, QScrollArea, QWidget, QColorDialog)
from PySide6.QtCore import Qt, QPoint, QRect, Signal
from PySide6.QtGui import QPainter, QPen, QColor, QPixmap
from ui.interactive_preview import FrameDrawingWidget

from utils.config_manager import load_json_config, save_json_config

def load_saved_effects_config():
    return load_json_config("config_effects.json", None)

def save_effects_config(config_data):
    save_json_config("config_effects.json", config_data)

class EffectsDrawingWidget(FrameDrawingWidget):
    def __init__(self, parent=None):
        super().__init__(parent)


class EffectsConfigDialog(QDialog):
    def __init__(self, video_path, ffmpeg_path, ffprobe_path, current_config=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Bảng cấu hình Chèn thêm - V2/Kéo thả trực tiếp")
        self.resize(1260, 780)
        
        self.video_path = video_path
        self.ffmpeg_path = ffmpeg_path
        self.ffprobe_path = ffprobe_path
        
        self.video_duration = 0.0
        self.current_time = 0.0
        self.temp_preview_img = os.path.join(os.environ.get("TEMP", "."), "effects_preview.jpg")
        
        saved = load_saved_effects_config()
        if current_config:
            self.config_data = current_config
        elif saved:
            self.config_data = saved
        else:
            self.config_data = {
                "bgm_enabled": False, "bgm_path": "", "bgm_vol": 60,
                "sub_enabled": True, "sub_font": "Bangers", "sub_size": 30,
                "sub_color": "#FFFFFF", "sub_outline": "#000000",
                "sub_bg_enabled": False, "sub_bg_color": "#000000", "sub_bg_opacity": 50,
                "sub_pct_y": 85.0,
                "mirror_enabled": False,
                "crop_enabled": False, "crop_ratio": "16:9", "crop_scale": 100,
                "logo_enabled": False, "logo_path": "", "logos": [], "logo_scale_pct": "100%",
                "blur_enabled": False, "blurs": []
            }
        
        self.init_ui()
        self.load_video_metadata()
        self.load_frame_at_time(0.0)

    def init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(12)

        # ---------------------------------------------
        # LEFT PANEL: VIDEO PREVIEW & NAVIGATION
        # ---------------------------------------------
        left_layout = QVBoxLayout()
        
        self.draw_widget = EffectsDrawingWidget()
        self.draw_widget.setFocusPolicy(Qt.StrongFocus)
        self.draw_widget.setAlignment(Qt.AlignCenter)
        self.draw_widget.setStyleSheet("border: 2px solid #334155; background-color: #020617; border-radius: 6px;")
        left_layout.addWidget(self.draw_widget)

        # Controls Buttons
        control_btns = QHBoxLayout()
        btn_back = QPushButton("<< Lùi")
        btn_back.clicked.connect(self.jump_backward)
        control_btns.addWidget(btn_back)

        box_frames = QHBoxLayout()
        box_frames.addWidget(QLabel("Nhảy:"))
        self.cb_frames = QComboBox()
        self.cb_frames.addItems(["50 frames", "100 frames", "5 giây"])
        box_frames.addWidget(self.cb_frames)
        control_btns.addLayout(box_frames)

        btn_forward = QPushButton("Tiến >>")
        btn_forward.clicked.connect(self.jump_forward)
        control_btns.addWidget(btn_forward)

        self.lbl_time = QLabel("00:00:00")
        self.lbl_time.setStyleSheet("font-weight: bold; color: #38bdf8; font-family: monospace; font-size: 13px;")
        control_btns.addWidget(self.lbl_time)

        btn_del_sel = QPushButton("Xóa Vùng Chọn")
        btn_del_sel.setStyleSheet("background-color: #dc2626; color: white; font-weight: bold;")
        btn_del_sel.clicked.connect(self.draw_widget.delete_selected)
        control_btns.addWidget(btn_del_sel)

        left_layout.addLayout(control_btns)
        main_layout.addLayout(left_layout, stretch=3)

        # ---------------------------------------------
        # RIGHT PANEL: SCROLLABLE SIDEBAR SETTINGS
        # ---------------------------------------------
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("""
            QScrollArea { border: 1px solid #334155; background-color: #0f172a; border-radius: 6px; }
            QGroupBox { font-size: 12px; font-weight: bold; color: #38bdf8; }
            QLabel { font-size: 11px; }
            QPushButton { font-size: 11px; padding: 4px 8px; }
            QComboBox { font-size: 11px; }
            QSpinBox { font-size: 11px; }
        """)
        
        scroll_content = QWidget()
        right_layout = QVBoxLayout(scroll_content)
        right_layout.setContentsMargins(8, 8, 8, 8)
        right_layout.setSpacing(8)

        # 1. Nhạc nền
        self.group_bgm = QGroupBox("Bật Nhạc Nền (Loop vô tận)")
        self.group_bgm.setCheckable(True)
        self.group_bgm.setChecked(self.config_data.get("bgm_enabled", False))
        bgm_layout = QVBoxLayout(self.group_bgm)
        bgm_layout.setContentsMargins(6, 6, 6, 6)
        
        box_bgm_file = QHBoxLayout()
        self.txt_bgm = QLineEdit(self.config_data.get("bgm_path", ""))
        self.txt_bgm.setPlaceholderText("Đường dẫn file .mp3 / .wav...")
        box_bgm_file.addWidget(self.txt_bgm)
        
        btn_browse_bgm = QPushButton("Chọn Nhạc")
        btn_browse_bgm.clicked.connect(self.browse_bgm)
        box_bgm_file.addWidget(btn_browse_bgm)
        bgm_layout.addLayout(box_bgm_file)

        box_bgm_vol = QHBoxLayout()
        box_bgm_vol.addWidget(QLabel("Âm lượng:"))
        self.sb_bgm_vol = QSpinBox()
        self.sb_bgm_vol.setRange(0, 100)
        self.sb_bgm_vol.setValue(self.config_data.get("bgm_vol", 60))
        box_bgm_vol.addWidget(self.sb_bgm_vol)
        box_bgm_vol.addStretch()
        bgm_layout.addLayout(box_bgm_vol)
        
        right_layout.addWidget(self.group_bgm)

        # 2. Cấu hình phụ đề
        self.group_sub = QGroupBox("Bật Cấu Hình Phụ Đề")
        self.group_sub.setCheckable(True)
        self.group_sub.setChecked(self.config_data.get("sub_enabled", True))
        sub_layout = QVBoxLayout(self.group_sub)
        sub_layout.setContentsMargins(6, 6, 6, 6)
        
        box_sub_row1 = QHBoxLayout()
        box_sub_row1.addWidget(QLabel("Font:"))
        self.cb_font = QComboBox()
        self.cb_font.addItems(["Arial", "Bangers", "Times New Roman", "Segoe UI", "Tahoma", "Montserrat", "Roboto"])
        self.cb_font.setCurrentText(self.config_data.get("sub_font", "Bangers"))
        self.cb_font.currentTextChanged.connect(self.update_sub_preview)
        box_sub_row1.addWidget(self.cb_font)

        self.btn_text_color = QPushButton("Màu Chữ")
        self.btn_text_color.setFixedWidth(70)
        self.btn_text_color.clicked.connect(self.pick_text_color)
        box_sub_row1.addWidget(self.btn_text_color)
        
        self.txt_text_color = QLineEdit(self.config_data.get("sub_color", "#FFFFFF"))
        self.txt_text_color.setVisible(False)

        self.btn_outline_color = QPushButton("Màu Viền")
        self.btn_outline_color.setFixedWidth(70)
        self.btn_outline_color.clicked.connect(self.pick_outline_color)
        box_sub_row1.addWidget(self.btn_outline_color)

        self.txt_outline = QLineEdit(self.config_data.get("sub_outline", "#000000"))
        self.txt_outline.setVisible(False)
        sub_layout.addLayout(box_sub_row1)

        box_sub_row2 = QHBoxLayout()
        box_sub_row2.addWidget(QLabel("Cỡ chữ:"))
        self.sb_size = QSpinBox()
        self.sb_size.setRange(10, 80)
        self.sb_size.setValue(self.config_data.get("sub_size", 30))
        self.sb_size.valueChanged.connect(self.update_sub_preview)
        box_sub_row2.addWidget(self.sb_size)

        box_sub_row2.addWidget(QLabel("Độ dày viền:"))
        self.sb_outline_w = QDoubleSpinBox()
        self.sb_outline_w.setRange(0.0, 10.0)
        self.sb_outline_w.setSingleStep(0.5)
        self.sb_outline_w.setValue(self.config_data.get("sub_outline_width", 3.5))
        self.sb_outline_w.valueChanged.connect(self.update_sub_preview)
        box_sub_row2.addWidget(self.sb_outline_w)
        sub_layout.addLayout(box_sub_row2)

        # Style Checkboxes Row (Bold, Italic, Shadow)
        box_sub_style = QHBoxLayout()
        self.chk_bold = QCheckBox("In đậm (Bold)")
        self.chk_bold.setChecked(self.config_data.get("sub_bold", True))
        self.chk_bold.toggled.connect(self.update_sub_preview)
        box_sub_style.addWidget(self.chk_bold)

        self.chk_italic = QCheckBox("Nghiêng (Italic)")
        self.chk_italic.setChecked(self.config_data.get("sub_italic", True))
        self.chk_italic.toggled.connect(self.update_sub_preview)
        box_sub_style.addWidget(self.chk_italic)

        self.chk_shadow = QCheckBox("Bóng đổ (Shadow)")
        self.chk_shadow.setChecked(self.config_data.get("sub_shadow", True))
        self.chk_shadow.toggled.connect(self.update_sub_preview)
        box_sub_style.addWidget(self.chk_shadow)
        sub_layout.addLayout(box_sub_style)

        box_sub_row3 = QHBoxLayout()
        self.chk_bg = QCheckBox("Bật Phông nền")
        self.chk_bg.setChecked(self.config_data.get("sub_bg_enabled", True))
        self.chk_bg.toggled.connect(self.update_sub_preview)
        box_sub_row3.addWidget(self.chk_bg)

        self.btn_bg_color = QPushButton("Màu Nền")
        self.btn_bg_color.setFixedWidth(70)
        self.btn_bg_color.clicked.connect(self.pick_bg_color)
        box_sub_row3.addWidget(self.btn_bg_color)

        self.txt_bg_color = QLineEdit(self.config_data.get("sub_bg_color", "#000000"))
        self.txt_bg_color.setVisible(False)

        box_sub_row3.addWidget(QLabel("Độ mờ:"))
        self.sb_bg_opacity = QSpinBox()
        self.sb_bg_opacity.setRange(0, 100)
        self.sb_bg_opacity.setValue(self.config_data.get("sub_bg_opacity", 50))
        self.sb_bg_opacity.valueChanged.connect(self.update_sub_preview)
        box_sub_row3.addWidget(self.sb_bg_opacity)
        sub_layout.addLayout(box_sub_row3)

        lbl_hint_sub = QLabel("💡 Kéo thả trực tiếp vị trí chữ lên/xuống bên màn Preview")
        lbl_hint_sub.setStyleSheet("color: #94a3b8; font-style: italic; font-size: 10px;")
        sub_layout.addWidget(lbl_hint_sub)

        right_layout.addWidget(self.group_sub)

        # 3. Gương video
        self.group_mirror = QGroupBox("Bật Gương Video (Lật ngang)")
        self.group_mirror.setCheckable(True)
        self.group_mirror.setChecked(self.config_data.get("mirror_enabled", False))
        right_layout.addWidget(self.group_mirror)

        # 4. Crop theo tỷ lệ
        self.group_crop = QGroupBox("Bật Cắt theo khung kích thước (Crop)")
        self.group_crop.setCheckable(True)
        self.group_crop.setChecked(self.config_data.get("crop_enabled", False))
        crop_layout = QHBoxLayout(self.group_crop)
        crop_layout.setContentsMargins(6, 6, 6, 6)
        
        crop_layout.addWidget(QLabel("Tỷ lệ:"))
        self.cb_crop_ratio = QComboBox()
        self.cb_crop_ratio.addItems(["16:9", "9:16", "1:1", "4:3"])
        self.cb_crop_ratio.setCurrentText(self.config_data.get("crop_ratio", "16:9"))
        crop_layout.addWidget(self.cb_crop_ratio)

        crop_layout.addWidget(QLabel("Phóng to:"))
        self.cb_crop_scale = QComboBox()
        self.cb_crop_scale.addItems(["100%", "110%", "120%"])
        crop_layout.addWidget(self.cb_crop_scale)
        right_layout.addWidget(self.group_crop)

        # 5. Đè Logo (Watermark)
        self.group_logo = QGroupBox("Bật Thêm Logo (Watermark)")
        self.group_logo.setCheckable(True)
        self.group_logo.setChecked(self.config_data.get("logo_enabled", False))
        logo_layout = QVBoxLayout(self.group_logo)
        logo_layout.setContentsMargins(6, 6, 6, 6)
        
        btn_add_logo = QPushButton("Thêm Logo Mới (Di chuyển)")
        btn_add_logo.setStyleSheet("background-color: #2563eb; color: white; font-weight: bold;")
        btn_add_logo.clicked.connect(self.browse_logo)
        logo_layout.addWidget(btn_add_logo)

        box_logo_item = QHBoxLayout()
        box_logo_item.addWidget(QLabel("Kích thước:"))
        self.cb_logo_size = QComboBox()
        self.cb_logo_size.setEditable(True)
        self.cb_logo_size.addItems(["100%", "80%", "60%", "50%", "40%", "20%", "10%"])
        self.cb_logo_size.setCurrentText(self.config_data.get("logo_scale_pct", "100%"))
        self.cb_logo_size.currentTextChanged.connect(self.on_logo_size_changed)
        box_logo_item.addWidget(self.cb_logo_size)

        self.cb_logo_motion = QComboBox()
        self.cb_logo_motion.addItems(["Đứng yên", "Chạy ngang", "Lướt dọc"])
        box_logo_item.addWidget(self.cb_logo_motion)

        btn_del_logo = QPushButton("Xóa")
        btn_del_logo.setStyleSheet("background-color: #dc2626; color: white;")
        btn_del_logo.clicked.connect(self.draw_widget.delete_selected)
        box_logo_item.addWidget(btn_del_logo)
        logo_layout.addLayout(box_logo_item)

        right_layout.addWidget(self.group_logo)

        # 6. Làm mờ Blur
        self.group_blur = QGroupBox("Bật Làm Mờ Blur")
        self.group_blur.setCheckable(True)
        self.group_blur.setChecked(self.config_data.get("blur_enabled", False))
        blur_layout = QVBoxLayout(self.group_blur)
        blur_layout.setContentsMargins(6, 6, 6, 6)
        
        btn_add_blur = QPushButton("Thêm Vùng Làm Mờ (Vẽ Bằng Chuột)")
        btn_add_blur.setStyleSheet("background-color: #dc2626; color: white; font-weight: bold;")
        btn_add_blur.clicked.connect(self.set_blur_mode)
        blur_layout.addWidget(btn_add_blur)

        box_blur_item = QHBoxLayout()
        box_blur_item.addWidget(QLabel("Vùng Blur 1"))
        
        self.cb_blur_type = QComboBox()
        self.cb_blur_type.addItems(["Tròn màu", "Làm mờ mượt", "Làm mờ đậm"])
        box_blur_item.addWidget(self.cb_blur_type)

        btn_del_blur = QPushButton("Xóa")
        btn_del_blur.setStyleSheet("background-color: #dc2626; color: white;")
        btn_del_blur.clicked.connect(self.draw_widget.delete_selected)
        box_blur_item.addWidget(btn_del_blur)
        blur_layout.addLayout(box_blur_item)

        right_layout.addWidget(self.group_blur)

        # Confirm / Save button - Dùng chữ VÀ thay cho dấu & để tránh gạch chân mnemonic Qt
        btn_save = QPushButton("💾 LƯU CẤU HÌNH VÀ ĐÓNG")
        btn_save.setStyleSheet("background-color: #2563eb; color: white; font-weight: bold; font-size: 13px; padding: 10px; border-radius: 6px;")
        btn_save.clicked.connect(self.save_and_close)
        right_layout.addWidget(btn_save)

        scroll.setWidget(scroll_content)
        scroll.setFixedWidth(440)
        main_layout.addWidget(scroll, stretch=2)

        self.draw_widget.sub_pct_y = self.config_data.get("sub_pct_y", 85.0)
        
        logo_path = self.config_data.get("logo_path", "")
        if logo_path and os.path.exists(logo_path):
            self.draw_widget.set_logo_image(logo_path, self.get_current_logo_scale())
            
        self.update_color_buttons()

    def pick_text_color(self):
        curr = QColor(self.txt_text_color.text().strip())
        color = QColorDialog.getColor(curr, self, "Chọn màu chữ phụ đề")
        if color.isValid():
            self.txt_text_color.setText(color.name().upper())
            self.update_color_buttons()

    def pick_outline_color(self):
        curr = QColor(self.txt_outline.text().strip())
        color = QColorDialog.getColor(curr, self, "Chọn màu viền phụ đề")
        if color.isValid():
            self.txt_outline.setText(color.name().upper())
            self.update_color_buttons()

    def pick_bg_color(self):
        curr = QColor(self.txt_bg_color.text().strip())
        color = QColorDialog.getColor(curr, self, "Chọn màu phông nền phụ đề")
        if color.isValid():
            self.txt_bg_color.setText(color.name().upper())
            self.update_color_buttons()

    def update_color_buttons(self):
        c_text = self.txt_text_color.text().strip()
        if len(c_text) == 7 and c_text.startswith("#"):
            self.btn_text_color.setStyleSheet(f"background-color: {c_text}; color: {'#000000' if c_text.upper() in ['#FFFFFF', '#FFFF00'] else '#FFFFFF'}; font-weight: bold;")
            self.draw_widget.sub_color = QColor(c_text)

        c_out = self.txt_outline.text().strip()
        if len(c_out) == 7 and c_out.startswith("#"):
            self.btn_outline_color.setStyleSheet(f"background-color: {c_out}; color: {'#000000' if c_out.upper() in ['#FFFFFF', '#FFFF00'] else '#FFFFFF'}; font-weight: bold;")
            self.draw_widget.sub_outline = QColor(c_out)

        c_bg = self.txt_bg_color.text().strip()
        if len(c_bg) == 7 and c_bg.startswith("#"):
            self.btn_bg_color.setStyleSheet(f"background-color: {c_bg}; color: {'#000000' if c_bg.upper() in ['#FFFFFF', '#FFFF00'] else '#FFFFFF'}; font-weight: bold;")
            
        self.update_sub_preview()

    def update_sub_preview(self):
        self.draw_widget.sub_font = self.cb_font.currentText()
        self.draw_widget.sub_size = self.sb_size.value()
        self.draw_widget.sub_bold = self.chk_bold.isChecked()
        self.draw_widget.sub_italic = self.chk_italic.isChecked()
        self.draw_widget.sub_shadow = self.chk_shadow.isChecked()
        self.draw_widget.sub_outline_width = self.sb_outline_w.value()
        
        color_hex = self.txt_outline.text().strip()
        if len(color_hex) == 7 and color_hex.startswith("#"):
            self.draw_widget.sub_outline = QColor(color_hex)
            
        self.draw_widget.sub_bg_enabled = self.chk_bg.isChecked()
        
        bg_hex = self.txt_bg_color.text().strip()
        if len(bg_hex) == 7 and bg_hex.startswith("#"):
            opacity = int(self.sb_bg_opacity.value() / 100.0 * 255)
            c = QColor(bg_hex)
            self.draw_widget.sub_bg_color = QColor(c.red(), c.green(), c.blue(), opacity)
            
        self.draw_widget.update()

    def browse_bgm(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn file nhạc nền BGM", "", "Âm thanh (*.mp3 *.wav)")
        if file_path:
            self.txt_bgm.setText(os.path.normpath(file_path))

    def browse_logo(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn ảnh Logo", "", "Hình ảnh (*.png *.jpg *.jpeg)")
        if file_path:
            norm_p = os.path.normpath(file_path)
            self.config_data["logo_path"] = norm_p
            self.group_logo.setChecked(True)
            
            self.draw_widget.set_logo_image(norm_p, self.get_current_logo_scale())
            self.draw_widget.mode = "logo"
            self.draw_widget.selected_target = ('logo', None)
            self.draw_widget.update()
            QMessageBox.information(self, "Thành công", "Đã nạp Logo! Ảnh Logo thực tế đã hiển thị trên màn hình Preview. Bạn có thể kéo di chuyển vị trí trực tiếp.")

    def get_current_logo_scale(self):
        text = self.cb_logo_size.currentText().strip()
        nums = re.findall(r"[-+]?\d*\.\d+|\d+", text)
        if nums:
            try:
                val = float(nums[0])
                return max(0.05, min(3.0, val / 100.0))
            except ValueError:
                pass
        return 1.0

    def on_logo_size_changed(self, text):
        scale = self.get_current_logo_scale()
        self.draw_widget.update_logo_scale(scale)

    def set_blur_mode(self):
        self.group_blur.setChecked(True)
        self.draw_widget.mode = "blur"
        QMessageBox.information(self, "Thông tin", "Kéo chuột vẽ ô màu đỏ bao phủ khu vực làm mờ. Bạn có thể bấm chọn ô để di chuyển/thay đổi kích thước.")

    def load_video_metadata(self):
        cmd = [
            self.ffprobe_path,
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            self.video_path
        ]
        try:
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            self.video_duration = float(proc.stdout.strip())
        except:
            self.video_duration = 60.0

    def load_frame_at_time(self, seconds):
        if not os.path.exists(self.video_path):
            return

        # Lưu lại tọa độ làm mờ & logo hiện tại đang chỉnh sửa trước khi chuyển sang frame mới
        if hasattr(self, 'draw_widget') and self.draw_widget.pixmap():
            curr_blurs, curr_logo, curr_sub_y = self.draw_widget.get_mapped_coordinates()
            if curr_blurs is not None:
                self.config_data["blurs"] = curr_blurs
            if curr_logo is not None:
                self.config_data["logos"] = [curr_logo]
            else:
                self.config_data["logos"] = []
                self.config_data["logo_enabled"] = False
                if hasattr(self, "group_logo"):
                    self.group_logo.setChecked(False)
            self.config_data["sub_pct_y"] = curr_sub_y

        self.current_time = max(0.0, min(self.video_duration, seconds))
        h = int(self.current_time // 3600)
        m = int((self.current_time % 3600) // 60)
        s = int(self.current_time % 60)
        time_str = f"{h:02d}:{m:02d}:{s:02d}"
        
        self.lbl_time.setText(time_str)

        cmd = [
            self.ffmpeg_path,
            "-y",
            "-ss", time_str,
            "-i", self.video_path,
            "-vframes", "1",
            "-q:v", "2",
            self.temp_preview_img
        ]
        try:
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        except:
            return

        if os.path.exists(self.temp_preview_img):
            pixmap = QPixmap(self.temp_preview_img)
            scaled = pixmap.scaled(720, 400, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            
            cmd_size = [
                self.ffprobe_path,
                "-v", "error",
                "-select_streams", "v:0",
                "-show_entries", "stream=width,height",
                "-of", "csv=p=0:s=x",
                self.video_path
            ]
            video_w, video_h = 1280, 720
            try:
                proc = subprocess.run(cmd_size, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                res = proc.stdout.strip().split("x")
                if len(res) == 2:
                    video_w, video_h = int(res[0]), int(res[1])
            except:
                pass
                
            self.draw_widget.set_frame(scaled, video_w, video_h)
            self.draw_widget.set_saved_coordinates(
                self.config_data.get("blurs", []),
                self.config_data.get("logos", []),
                self.config_data.get("sub_pct_y", 85.0)
            )
            self.update_sub_preview()

    def jump_forward(self):
        step_text = self.cb_frames.currentText()
        jump = 2.0
        if "5 giây" in step_text:
            jump = 5.0
        elif "100" in step_text:
            jump = 3.33
        
        new_t = min(self.video_duration, self.current_time + jump)
        self.load_frame_at_time(new_t)

    def jump_backward(self):
        step_text = self.cb_frames.currentText()
        jump = 2.0
        if "5 giây" in step_text:
            jump = 5.0
        elif "100" in step_text:
            jump = 3.33
        
        new_t = max(0.0, self.current_time - jump)
        self.load_frame_at_time(new_t)

    def save_and_close(self):
        self.config_data["bgm_enabled"] = self.group_bgm.isChecked()
        self.config_data["bgm_path"] = self.txt_bgm.text().strip()
        self.config_data["bgm_vol"] = self.sb_bgm_vol.value()

        self.config_data["sub_enabled"] = self.group_sub.isChecked()
        self.config_data["sub_font"] = self.cb_font.currentText()
        self.config_data["sub_size"] = self.sb_size.value()
        self.config_data["sub_color"] = self.txt_text_color.text().strip()
        self.config_data["sub_outline"] = self.txt_outline.text().strip()
        self.config_data["sub_bold"] = self.chk_bold.isChecked()
        self.config_data["sub_italic"] = self.chk_italic.isChecked()
        self.config_data["sub_shadow"] = self.chk_shadow.isChecked()
        self.config_data["sub_outline_width"] = self.sb_outline_w.value()
        self.config_data["sub_bg_enabled"] = self.chk_bg.isChecked()
        self.config_data["sub_bg_color"] = self.txt_bg_color.text().strip()
        self.config_data["sub_bg_opacity"] = self.sb_bg_opacity.value()

        self.config_data["mirror_enabled"] = self.group_mirror.isChecked()
        self.config_data["crop_enabled"] = self.group_crop.isChecked()
        self.config_data["crop_ratio"] = self.cb_crop_ratio.currentText()

        self.config_data["logo_enabled"] = self.group_logo.isChecked()
        self.config_data["logo_scale_pct"] = self.cb_logo_size.currentText().strip()

        self.config_data["blur_enabled"] = self.group_blur.isChecked()

        blurs, logo, sub_pct_y = self.draw_widget.get_mapped_coordinates()
        self.config_data["blurs"] = blurs
        self.config_data["sub_pct_y"] = sub_pct_y
        
        if logo and self.config_data.get("logo_path"):
            logo["path"] = self.config_data["logo_path"]
            self.config_data["logos"] = [logo]
        else:
            self.config_data["logos"] = []

        save_effects_config(self.config_data)
        QMessageBox.information(self, "Thành công", "Đã lưu lại toàn bộ cấu hình hiệu ứng, logo và vùng mờ vào bộ nhớ!")
        self.accept()

    def closeEvent(self, event):
        if os.path.exists(self.temp_preview_img):
            try:
                os.remove(self.temp_preview_img)
            except:
                pass
        super().closeEvent(event)
