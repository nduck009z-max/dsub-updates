import os
import time
import tempfile
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, 
                             QLineEdit, QPushButton, QComboBox, QCheckBox, 
                             QProgressBar, QTextEdit, QFileDialog, QMessageBox, QGroupBox, QSpinBox, QRadioButton)
from PySide6.QtCore import QThread, Signal, Slot, Qt
from core.tts import TTSEngine
from core.renderer import VideoRenderer
from ui.dialog_effects import EffectsConfigDialog, load_saved_effects_config
from utils.config_manager import load_json_config, save_json_config

def load_saved_render_config():
    return load_json_config("config_render.json", None)

def save_saved_render_config(data):
    save_json_config("config_render.json", data)

class RenderThread(QThread):
    progress = Signal(int)
    log = Signal(str)
    finished_status = Signal(bool)

    def __init__(self, tts_engine, srt_subtitles_list, srt_file_path, output_audio, video_path, output_video,
                 effects_config, settings_tab=None, orig_vol=0.1, tts_vol=1.0, codec="libx264", preset="medium", crf=23, max_duration=None):
        super().__init__()
        self.tts_engine = tts_engine
        self.srt_subtitles_list = srt_subtitles_list
        self.srt_file_path = srt_file_path
        self.output_audio = output_audio
        self.video_path = video_path
        self.output_video = output_video
        self.effects_config = effects_config
        self.settings_tab = settings_tab
        
        self.orig_vol = orig_vol
        self.tts_vol = tts_vol
        self.codec = codec
        self.preset = preset
        self.crf = crf
        self.max_duration = max_duration

    def run(self):
        def log_cb(msg):
            self.log.emit(msg)

        def progress_cb(pct):
            self.progress.emit(int(pct * 0.4))

        try:
            log_cb("🔍 Kiểm tra audio cache & giọng đọc thuyết minh...")
            
            piper_p = None
            if self.settings_tab:
                settings = self.settings_tab.get_settings()
                piper_p = settings.get("piper_path")
            
            if not piper_p or not os.path.exists(piper_p):
                local_piper = os.path.join(os.getcwd(), "piper", "piper.exe")
                if os.path.exists(local_piper):
                    piper_p = local_piper

            fixed_temp_dir = os.path.normpath(os.path.join(os.getcwd(), "temp_audio_chunks"))
            os.makedirs(fixed_temp_dir, exist_ok=True)

            success, failed_subs = self.tts_engine.generate_full_dubbing(
                srt_file=self.srt_subtitles_list,
                output_audio_file=self.output_audio,
                provider="edge",
                voice_or_model="vi-VN-HoaiMyNeural",
                piper_exe_path=piper_p,
                auto_speedup=True,
                custom_temp_dir=fixed_temp_dir,
                log_cb=log_cb,
                progress_cb=progress_cb
            )

            if not success:
                log_cb("❌ Sinh audio thất bại — Hủy render.")
                self.finished_status.emit(False)
                return

            log_cb("\n🎥 Ghép thuyết minh & áp dụng hiệu ứng video...")
            
            import shutil
            ffmpeg_p = self.tts_engine.ffmpeg_path
            if not ffmpeg_p or not os.path.exists(ffmpeg_p):
                sys_ffmpeg = shutil.which("ffmpeg")
                if sys_ffmpeg and os.path.exists(sys_ffmpeg):
                    ffmpeg_p = sys_ffmpeg
                else:
                    rel_ffmpeg = os.path.join(os.getcwd(), "ffmpeg_bin", "ffmpeg.exe")
                    if os.path.exists(rel_ffmpeg):
                        ffmpeg_p = rel_ffmpeg
                    else:
                        zk_ffmpeg = r"C:\Users\Admin\Desktop\ZKApps_v3_0\ffmpeg_bin\ffmpeg.exe"
                        if os.path.exists(zk_ffmpeg):
                            ffmpeg_p = zk_ffmpeg

            ffmpeg_dir = os.path.dirname(ffmpeg_p) if os.path.isabs(ffmpeg_p) else ""
            ffprobe_path = os.path.join(ffmpeg_dir, "ffprobe.exe") if ffmpeg_dir else "ffprobe"
            if not os.path.exists(ffprobe_path):
                sys_ffprobe = shutil.which("ffprobe")
                if sys_ffprobe and os.path.exists(sys_ffprobe):
                    ffprobe_path = sys_ffprobe
                else:
                    rel_ffprobe = os.path.join(os.getcwd(), "ffmpeg_bin", "ffprobe.exe")
                    if os.path.exists(rel_ffprobe):
                        ffprobe_path = rel_ffprobe

            renderer = VideoRenderer(ffmpeg_path=ffmpeg_p, ffprobe_path=ffprobe_path)

            def render_progress_cb(pct):
                self.progress.emit(40 + int(pct * 0.6))

            bgm_path = self.effects_config.get("bgm_path") if self.effects_config.get("bgm_enabled") else None
            bgm_vol = self.effects_config.get("bgm_vol", 20) / 100.0
            
            srt_burn_path = self.srt_file_path
            if self.srt_file_path and self.srt_subtitles_list:
                try:
                    from core.srt_parser import write_srt
                    temp_srt_path = os.path.join(tempfile.gettempdir(), f"cumulative_offset_{int(time.time())}.srt")
                    write_srt(self.srt_subtitles_list, temp_srt_path)
                    srt_burn_path = temp_srt_path
                    log_cb(f"📝 Phụ đề SRT tạm đã xuất: {os.path.basename(temp_srt_path)}")
                except Exception as srt_err:
                    log_cb(f"⚠️ Không xuất được SRT dồn offset: {srt_err}")

            if "sub_enabled" in self.effects_config and not self.effects_config["sub_enabled"]:
                srt_burn_path = None
            
            blurs = self.effects_config.get("blurs") if self.effects_config.get("blur_enabled") else None
            logos = self.effects_config.get("logos") if self.effects_config.get("logo_enabled") else None

            sub_style = {
                "font": self.effects_config.get("sub_font", "Bangers"),
                "size": self.effects_config.get("sub_size", 30),
                "color": self.effects_config.get("sub_color", "#FFFFFF"),
                "outline_color": self.effects_config.get("sub_outline", "#000000"),
                "bold": self.effects_config.get("sub_bold", True),
                "italic": self.effects_config.get("sub_italic", True),
                "shadow": self.effects_config.get("sub_shadow", True),
                "outline_width": self.effects_config.get("sub_outline_width", 3.5),
                "bg_enabled": self.effects_config.get("sub_bg_enabled", False),
                "pct_y": self.effects_config.get("sub_pct_y", 85.0)
            }

            render_success = renderer.render_video(
                video_path=self.video_path,
                tts_audio_path=self.output_audio,
                output_path=self.output_video,
                bgm_path=bgm_path,
                srt_path=srt_burn_path,
                blurs=blurs,
                logos=logos,
                orig_vol=self.orig_vol,
                tts_vol=self.tts_vol,
                bgm_vol=bgm_vol,
                codec=self.codec,
                preset=self.preset,
                crf=self.crf,
                sub_style=sub_style,
                max_duration=self.max_duration,
                log_cb=log_cb,
                progress_cb=render_progress_cb,
                subtitles_list=self.srt_subtitles_list
            )
            
            # Tự động fallback từ GPU NVENC sang CPU libx264 nếu NVENC không tương thích với máy
            if not render_success and ("nvenc" in self.codec):
                log_cb("\n⚠️ GPU (NVENC) lỗi trên máy này → Tự động chuyển sang CPU (libx264)...")
                render_success = renderer.render_video(
                    video_path=self.video_path,
                    tts_audio_path=self.output_audio,
                    output_path=self.output_video,
                    bgm_path=bgm_path,
                    srt_path=srt_burn_path,
                    blurs=blurs,
                    logos=logos,
                    orig_vol=self.orig_vol,
                    tts_vol=self.tts_vol,
                    bgm_vol=bgm_vol,
                    codec="libx264",
                    preset=self.preset,
                    crf=self.crf,
                    sub_style=sub_style,
                    max_duration=self.max_duration,
                    log_cb=log_cb,
                    progress_cb=render_progress_cb,
                    subtitles_list=self.srt_subtitles_list
                )

            self.finished_status.emit(render_success)
        except Exception as ex:
            import traceback
            err_str = traceback.format_exc()
            log_cb(f"\n❌ Ngoại lệ render:\n{err_str}")
            self.finished_status.emit(False)
        finally:
            # Tự động dọn dẹp file âm thanh tạm để thư mục xuất video CHỈ CHỨA DUY NHẤT 1 FILE VIDEO
            if self.output_audio and os.path.exists(self.output_audio):
                try:
                    os.remove(self.output_audio)
                    log_cb("[Hệ thống] Đã dọn dẹp bộ nhớ file âm thanh tạm.")
                except Exception:
                    pass


class RenderDialog(QDialog):
    def __init__(self, srt_subtitles_list, srt_file_path, settings_tab, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Render Video Tốc Độ Cao - DSub v1.2")
        self.resize(780, 620)
        self.srt_subtitles_list = srt_subtitles_list
        self.srt_file_path = srt_file_path
        self.settings_tab = settings_tab
        self.thread = None
        
        saved = load_saved_effects_config()
        self.effects_config = saved if saved else {
            "bgm_enabled": False, "bgm_path": "", "bgm_vol": 60,
            "sub_enabled": True, "sub_font": "Bangers", "sub_size": 30,
            "sub_color": "#FFFFFF", "sub_outline": "#000000",
            "sub_bg_enabled": True, "sub_bg_color": "#000000", "sub_bg_opacity": 50,
            "sub_pct_y": 85.0,
            "mirror_enabled": False,
            "crop_enabled": False, "crop_ratio": "16:9", "crop_scale": 100,
            "logo_enabled": False, "logo_path": "", "logos": [], "logo_scale_pct": "100%",
            "blur_enabled": False, "blurs": []
        }

        self.init_ui()
        self.load_render_config()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        # 1. Chọn Video Gốc
        g1 = QGroupBox("1. Chọn Video Gốc (Không dấu / Tên hợp lệ)")
        g1_layout = QHBoxLayout(g1)
        g1_layout.setContentsMargins(10, 10, 10, 10)
        g1_layout.setSpacing(8)
        self.txt_video = QLineEdit()
        self.txt_video.setPlaceholderText("Đường dẫn file video gốc .mp4 / .mkv...")
        g1_layout.addWidget(self.txt_video)
        btn_video = QPushButton("📁 Chọn File")
        btn_video.setStyleSheet("background-color: #1e293b; color: white;")
        btn_video.clicked.connect(self.browse_video)
        g1_layout.addWidget(btn_video)
        layout.addWidget(g1)

        # 2. Chọn Nơi Lưu Video
        g2 = QGroupBox("2. Chọn Nơi Lưu Video Đầu Ra")
        g2_layout = QHBoxLayout(g2)
        g2_layout.setContentsMargins(10, 10, 10, 10)
        g2_layout.setSpacing(8)
        self.txt_video_out = QLineEdit()
        self.txt_video_out.setPlaceholderText("Đường dẫn file xuất...")
        g2_layout.addWidget(self.txt_video_out)
        btn_save = QPushButton("💾 Chọn Nơi Lưu")
        btn_save.setStyleSheet("background-color: #1e293b; color: white;")
        btn_save.clicked.connect(self.browse_save)
        g2_layout.addWidget(btn_save)
        layout.addWidget(g2)

        # 3. Hiệu ứng thêm
        g3 = QGroupBox("3. Chèn Nhạc nền | Phụ đề | Logo | Làm mờ")
        g3_layout = QHBoxLayout(g3)
        g3_layout.setContentsMargins(10, 10, 10, 10)
        g3_layout.setSpacing(12)
        self.chk_effects = QCheckBox("Bật / Tắt chèn hiệu ứng (Đã nạp cấu hình đã lưu)")
        self.chk_effects.setChecked(True)
        g3_layout.addWidget(self.chk_effects)
        
        btn_effects = QPushButton("🎨 MỞ BẢNG CHÈN THÊM")
        btn_effects.setStyleSheet("background-color: #7c3aed; color: white; padding: 7px 16px; font-size: 12px;")
        btn_effects.clicked.connect(self.open_effects_dialog)
        g3_layout.addWidget(btn_effects)
        layout.addWidget(g3)

        # 4. Encoder options Grid Layout
        g4 = QGroupBox("4. Cài Đặt Mã Hóa Video (Encoder)")
        g4_grid = QGridLayout(g4)
        g4_grid.setContentsMargins(12, 12, 12, 12)
        g4_grid.setHorizontalSpacing(16)
        g4_grid.setVerticalSpacing(10)

        # Row 0: Batch Size & Codec
        lbl_batch = QLabel("Số đoạn mỗi mẻ:")
        self.sb_batch = QSpinBox()
        self.sb_batch.setRange(1, 100)
        self.sb_batch.setValue(10)
        
        lbl_codec = QLabel("Encoder:")
        self.cb_codec = QComboBox()
        self.cb_codec.addItems(["CPU (libx264)", "GPU (h264_nvenc)"])
        self.cb_codec.setCurrentIndex(0)

        g4_grid.addWidget(lbl_batch, 0, 0)
        g4_grid.addWidget(self.sb_batch, 0, 1)
        g4_grid.addWidget(lbl_codec, 0, 2)
        g4_grid.addWidget(self.cb_codec, 0, 3)

        # Row 1: Preset & CRF
        lbl_preset = QLabel("Tốc độ (Preset):")
        self.cb_preset = QComboBox()
        self.cb_preset.addItems(["ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow"])
        self.cb_preset.setCurrentText("ultrafast")

        lbl_crf = QLabel("Độ Nét (CRF/CQ):")
        self.sb_crf = QSpinBox()
        self.sb_crf.setRange(1, 51)
        self.sb_crf.setValue(23)

        g4_grid.addWidget(lbl_preset, 1, 0)
        g4_grid.addWidget(self.cb_preset, 1, 1)
        g4_grid.addWidget(lbl_crf, 1, 2)
        g4_grid.addWidget(self.sb_crf, 1, 3)

        # Row 2: Volumes
        lbl_orig_vol = QLabel("Âm lượng Video gốc (%):")
        self.sb_orig_vol = QSpinBox()
        self.sb_orig_vol.setRange(0, 100)
        self.sb_orig_vol.setValue(50)

        lbl_tts_vol = QLabel("Âm lượng Thuyết minh (%):")
        self.sb_tts_vol = QSpinBox()
        self.sb_tts_vol.setRange(0, 200)
        self.sb_tts_vol.setValue(100)

        g4_grid.addWidget(lbl_orig_vol, 2, 0)
        g4_grid.addWidget(self.sb_orig_vol, 2, 1)
        g4_grid.addWidget(lbl_tts_vol, 2, 2)
        g4_grid.addWidget(self.sb_tts_vol, 2, 3)

        # Row 3: Video Scale Radio Buttons
        lbl_quality = QLabel("Kích thước Video:")
        box_radios = QHBoxLayout()
        box_radios.setSpacing(16)
        
        self.rb_orig = QRadioButton("Gốc")
        self.rb_orig.setChecked(True)
        self.rb_hd = QRadioButton("HD (720p)")
        self.rb_fhd = QRadioButton("FHD (1080p)")
        self.rb_2k = QRadioButton("2K (1440p)")
        
        box_radios.addWidget(self.rb_orig)
        box_radios.addWidget(self.rb_hd)
        box_radios.addWidget(self.rb_fhd)
        box_radios.addWidget(self.rb_2k)
        box_radios.addStretch()

        g4_grid.addWidget(lbl_quality, 3, 0)
        g4_grid.addLayout(box_radios, 3, 1, 1, 3)

        layout.addWidget(g4)

        # Buttons Panel
        box_btns = QHBoxLayout()
        box_btns.setSpacing(10)

        btn_sample = QPushButton("⏱️ Tạo Video Mẫu (30s)")
        btn_sample.setStyleSheet("background-color: #d97706; color: white;")
        btn_sample.clicked.connect(self.start_sample_render)
        box_btns.addWidget(btn_sample)

        self.btn_start = QPushButton("🚀 BẮT ĐẦU RENDER")
        self.btn_start.setStyleSheet("background-color: #16a34a; color: white; font-size: 13px; padding: 8px 18px;")
        self.btn_start.clicked.connect(self.start_render)
        box_btns.addWidget(self.btn_start)

        btn_split = QPushButton("📊 BẢNG PHÂN ĐOẠN")
        btn_split.setStyleSheet("background-color: #0284c7; color: white;")
        btn_split.clicked.connect(self.show_segment_table)
        box_btns.addWidget(btn_split)

        self.btn_stop = QPushButton("⏹️ DỪNG")
        self.btn_stop.setStyleSheet("background-color: #dc2626; color: white;")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop_render)
        box_btns.addWidget(self.btn_stop)
        layout.addLayout(box_btns)

        # Progress Bar & Console Log Output
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("QProgressBar { border: 1px solid #334155; border-radius: 4px; height: 18px; text-align: center; } QProgressBar::chunk { background-color: #16a34a; }")
        layout.addWidget(self.progress_bar)

        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        self.txt_log.setStyleSheet("background-color: #020617; color: #38bdf8; font-family: monospace; font-size: 11px; border: 1px solid #1e293b; border-radius: 6px; padding: 6px;")
        layout.addWidget(self.txt_log)

    def load_render_config(self):
        render_saved = load_saved_render_config()
        if render_saved:
            if render_saved.get("video_path") and os.path.exists(render_saved.get("video_path")):
                self.txt_video.setText(render_saved.get("video_path"))
            if render_saved.get("video_out_path"):
                self.txt_video_out.setText(render_saved.get("video_out_path"))
            if render_saved.get("batch_size"):
                self.sb_batch.setValue(render_saved.get("batch_size"))
            if render_saved.get("codec"):
                self.cb_codec.setCurrentText(render_saved.get("codec"))
            if render_saved.get("preset"):
                self.cb_preset.setCurrentText(render_saved.get("preset"))
            if render_saved.get("crf"):
                self.sb_crf.setValue(render_saved.get("crf"))
            if render_saved.get("orig_vol") is not None:
                self.sb_orig_vol.setValue(render_saved.get("orig_vol"))
            if render_saved.get("tts_vol") is not None:
                self.sb_tts_vol.setValue(render_saved.get("tts_vol"))
            
            q_scale = render_saved.get("quality_scale")
            if q_scale == "hd": self.rb_hd.setChecked(True)
            elif q_scale == "fhd": self.rb_fhd.setChecked(True)
            elif q_scale == "2k": self.rb_2k.setChecked(True)
            else: self.rb_orig.setChecked(True)

    def save_current_render_config(self):
        q_scale = "orig"
        if self.rb_hd.isChecked(): q_scale = "hd"
        elif self.rb_fhd.isChecked(): q_scale = "fhd"
        elif self.rb_2k.isChecked(): q_scale = "2k"

        cfg = {
            "video_path": self.txt_video.text().strip(),
            "video_out_path": self.txt_video_out.text().strip(),
            "batch_size": self.sb_batch.value(),
            "codec": self.cb_codec.currentText(),
            "preset": self.cb_preset.currentText(),
            "crf": self.sb_crf.value(),
            "orig_vol": self.sb_orig_vol.value(),
            "tts_vol": self.sb_tts_vol.value(),
            "quality_scale": q_scale
        }
        save_saved_render_config(cfg)

    def browse_video(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn file Video gốc", "", "Video Files (*.mp4 *.mkv *.avi *.mov)")
        if file_path:
            norm_path = os.path.normpath(file_path)
            self.txt_video.setText(norm_path)
            
            dir_name = os.path.dirname(norm_path)
            base_name = os.path.basename(norm_path)
            name_part, ext = os.path.splitext(base_name)
            out_default = os.path.join(dir_name, f"{name_part}_render{ext}")
            self.txt_video_out.setText(out_default)
            self.save_current_render_config()

    def browse_save(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Chọn vị trí lưu Video xuất", self.txt_video_out.text(), "MP4 Video (*.mp4)")
        if file_path:
            self.txt_video_out.setText(os.path.normpath(file_path))
            self.save_current_render_config()

    def open_effects_dialog(self):
        video_p = self.txt_video.text().strip()
        if not video_p or not os.path.exists(video_p):
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng chọn file Video gốc trước khi mở Bảng chèn thêm.")
            return

        settings = self.settings_tab.get_settings()
        ffmpeg_p = settings.get("ffmpeg_path", "ffmpeg")
        ffprobe_p = os.path.join(os.path.dirname(ffmpeg_p), "ffprobe.exe")
        if not os.path.exists(ffprobe_p):
            ffprobe_p = "ffprobe"

        dlg = EffectsConfigDialog(video_p, ffmpeg_p, ffprobe_p, current_config=self.effects_config, parent=self)
        if dlg.exec() == QDialog.Accepted:
            self.effects_config = dlg.config_data
            QMessageBox.information(self, "Thông báo", "Đã cập nhật cấu hình chèn thêm cho lần Render này!")

    def _cleanup_thread(self):
        """Ngắt kết nối và dọn thread cũ trước khi tạo thread mới, tránh signal chồng chéo."""
        if self.thread:
            try:
                self.thread.progress.disconnect()
            except Exception:
                pass
            try:
                self.thread.log.disconnect()
            except Exception:
                pass
            try:
                self.thread.finished_status.disconnect()
            except Exception:
                pass
            if self.thread.isRunning():
                if hasattr(self.thread, 'tts_engine'):
                    self.thread.tts_engine.is_running = False
                self.thread.terminate()
                self.thread.wait(3000)
            self.thread = None

    def check_free_disk_space(self, target_path, min_gb=1.0):
        try:
            target_dir = os.path.dirname(os.path.abspath(target_path))
            if not os.path.exists(target_dir):
                target_dir = os.path.abspath(os.sep)
            usage = shutil.disk_usage(target_dir)
            free_gb = usage.free / (1024 ** 3)
            if free_gb < min_gb:
                msg = f"⚠️ CẢNH BÁO DUNG LƯỢNG Ổ ĐĨA THẤP!\n\nỔ đĩa lưu trữ '{target_dir}' chỉ còn trống {free_gb:.2f} GB (khuyến nghị tối thiểu {min_gb:.1f} GB).\n\nBạn có muốn tiếp tục Render không?"
                reply = QMessageBox.warning(self, "Cảnh báo Dung lượng Đĩa", msg, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                return reply == QMessageBox.Yes
        except Exception:
            pass
        return True

    def start_render(self):
        video_p = self.txt_video.text().strip()

        if not video_p or not os.path.exists(video_p):
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng chọn file Video gốc hợp lệ.")
            return

        dir_name = os.path.dirname(video_p)
        orig_base = os.path.basename(video_p)
        name_part, ext = os.path.splitext(orig_base)
        
        out_p = self.txt_video_out.text().strip()
        if not out_p:
            out_p = os.path.join(dir_name, f"{name_part}_render{ext}")
            self.txt_video_out.setText(out_p)

        if not self.check_free_disk_space(out_p):
            return

        self.save_current_render_config()

        settings = self.settings_tab.get_settings()
        ffmpeg_p = settings.get("ffmpeg_path", "ffmpeg")
        models_d = settings.get("models_dir", "")
        
        # Đặt file audio tạm trong thư mục TEMP của hệ thống để dọn dẹp tuyệt đối, không để file audio rác ở folder đầu ra
        out_audio = os.path.join(tempfile.gettempdir(), f"{name_part}_dubbing_temp_{int(time.time())}.wav")

        tts_engine = TTSEngine(ffmpeg_path=ffmpeg_p, csv_dir=models_d)

        codec_str = "libx264" if "CPU" in self.cb_codec.currentText() else "h264_nvenc"
        preset_str = self.cb_preset.currentText()
        crf_val = self.sb_crf.value()

        orig_vol_float = self.sb_orig_vol.value() / 100.0
        tts_vol_float = self.sb_tts_vol.value() / 100.0

        eff_config = self.effects_config if self.chk_effects.isChecked() else {}

        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.progress_bar.setValue(0)
        self.txt_log.clear()

        self._cleanup_thread()
        self.thread = RenderThread(
            tts_engine=tts_engine,
            srt_subtitles_list=self.srt_subtitles_list,
            srt_file_path=self.srt_file_path,
            output_audio=out_audio,
            video_path=video_p,
            output_video=out_p,
            effects_config=eff_config,
            settings_tab=self.settings_tab,
            orig_vol=orig_vol_float,
            tts_vol=tts_vol_float,
            codec=codec_str,
            preset=preset_str,
            crf=crf_val
        )

        self.thread.progress.connect(self.progress_bar.setValue)
        self.thread.log.connect(self.append_log)
        self.thread.finished_status.connect(self.on_render_finished)
        self.thread.start()

    def stop_render(self):
        if self.thread and self.thread.isRunning():
            if hasattr(self.thread, 'tts_engine'):
                self.thread.tts_engine.is_running = False
            renderer_obj = getattr(self.thread, '_renderer_ref', None)
            if renderer_obj:
                renderer_obj.is_running = False
            self.thread.terminate()
            self.thread.wait(2000)
            self.append_log("\n⏹ Render đã bị dừng bởi người dùng.")
            self.btn_start.setEnabled(True)
            self.btn_stop.setEnabled(False)

    def on_render_finished(self, success):
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        
        if success:
            self.progress_bar.setValue(100)
            out_path = self.txt_video_out.text().strip()
            
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Render Video Hoàn Tất")
            msg_box.setText("🎉 <b>QUÁ TRÌNH RENDER VIDEO ĐÃ HOÀN TẤT THÀNH CÔNG!</b>")
            msg_box.setInformativeText(f"File video đã xuất tại:\n{out_path}\n\nBạn muốn thực hiện thao tác nào tiếp theo?")
            msg_box.setIcon(QMessageBox.Information)

            btn_play = msg_box.addButton("👁️ Xem Video", QMessageBox.ActionRole)
            btn_play.setStyleSheet("background-color: #0284c7; color: white; font-weight: bold; padding: 6px 14px; border-radius: 6px;")

            btn_open_folder = msg_box.addButton("📂 Đến Mục Lưu", QMessageBox.ActionRole)
            btn_open_folder.setStyleSheet("background-color: #059669; color: white; font-weight: bold; padding: 6px 14px; border-radius: 6px;")

            btn_close = msg_box.addButton("Đóng", QMessageBox.RejectRole)
            btn_close.setStyleSheet("background-color: #475569; color: white; padding: 6px 14px; border-radius: 6px;")

            msg_box.exec()

            clicked = msg_box.clickedButton()
            if clicked == btn_play:
                if os.path.exists(out_path):
                    os.startfile(out_path)
            elif clicked == btn_open_folder:
                if os.path.exists(out_path):
                    import subprocess
                    subprocess.Popen(f'explorer /select,"{os.path.abspath(out_path)}"')
                elif os.path.exists(os.path.dirname(out_path)):
                    os.startfile(os.path.dirname(out_path))
        else:
            log_text = self.txt_log.toPlainText().strip()
            log_lines = log_text.splitlines()
            error_details = "\n".join(log_lines[-15:])
            QMessageBox.critical(
                self,
                "Lỗi Render Video",
                f"❌ Quá trình Render Video bị lỗi!\n\nChi tiết Log thông báo:\n{error_details}"
            )

    @Slot(str)
    def append_log(self, text):
        if not text:
            return
        # Nếu đã có HTML formatting thì append trực tiếp
        if "<span" in text or "<font" in text or "<p" in text:
            self.txt_log.append(text)
            return

        # Phân màu dựa trên icon/từ khóa log
        if any(k in text for k in ["❌", "Lỗi", "ERROR", "thất bại"]):
            color = "#f87171"  # Đỏ nhạt
        elif any(k in text for k in ["🟢", "🎉", "hoàn tất", "Thành công", "khít"]):
            color = "#4ade80"  # Xanh lá tươi
        elif any(k in text for k in ["⚠️", "Cảnh báo", "WARNING", "cao"]):
            color = "#fbbf24"  # Vàng hổ phách
        elif any(k in text for k in ["🎬", "🔵", "Hệ thống", "Thông tin", "Đang"]):
            color = "#38bdf8"  # Xanh da trời Accent
        elif any(k in text for k in ["👑", "VIP"]):
            color = "#c084fc"  # Tím VIP
        else:
            color = "#cbd5e1"  # Xám sáng
        
        # Escape các ký tự HTML cơ bản để tránh lỗi hiển thị
        safe_text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
        formatted_html = f'<span style="color: {color}; font-family: Consolas, monospace; font-size: 11px;">{safe_text}</span>'
        self.txt_log.append(formatted_html)


    def start_sample_render(self):
        video_p = self.txt_video.text().strip()
        if not video_p or not os.path.exists(video_p):
            QMessageBox.warning(self, "Cảnh báo", "Vui lòng chọn file Video gốc hợp lệ trước khi xem thử mẫu 30s.")
            return

        import copy
        sample_subs_raw = [s for s in self.srt_subtitles_list if s.start.total_seconds() <= 30.0]
        if not sample_subs_raw:
            sample_subs_raw = self.srt_subtitles_list[:5]

        # Xóa audio_path cũ để TTS tái tạo fresh mỗi lần render mẫu (tránh cache stale từ lần trước)
        for s in self.srt_subtitles_list:
            if hasattr(s, 'audio_path'):
                s.audio_path = None
        sample_subs = copy.deepcopy(sample_subs_raw)

        dir_name = os.path.dirname(video_p)
        orig_base = os.path.basename(video_p)
        name_part, ext = os.path.splitext(orig_base)
        out_sample = os.path.join(dir_name, f"{name_part}_30s{ext}")
        self.txt_video_out.setText(out_sample)
        
        if not self.check_free_disk_space(out_sample):
            return
        
        self.save_current_render_config()

        settings = self.settings_tab.get_settings()
        ffmpeg_p = settings.get("ffmpeg_path", "ffmpeg")
        models_d = settings.get("models_dir", "")
        
        out_audio = os.path.join(tempfile.gettempdir(), f"{name_part}_sample_30s_dubbing_temp_{int(time.time())}.wav")
        tts_engine = TTSEngine(ffmpeg_path=ffmpeg_p, csv_dir=models_d)

        codec_str = "libx264" if "CPU" in self.cb_codec.currentText() else "h264_nvenc"
        preset_str = self.cb_preset.currentText()
        crf_val = self.sb_crf.value()

        orig_vol_float = self.sb_orig_vol.value() / 100.0
        tts_vol_float = self.sb_tts_vol.value() / 100.0

        eff_config = self.effects_config if self.chk_effects.isChecked() else {}

        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.progress_bar.setValue(0)
        self.txt_log.clear()

        self.append_log(f"🎬 [Hệ thống] Trực tiếp khởi chạy Render Mẫu 30s ({len(sample_subs)} câu thoại)...")

        temp_sample_srt = os.path.join(tempfile.gettempdir(), f"sample_30s_{int(time.time())}.srt")
        try:
            write_srt(sample_subs, temp_sample_srt)
            sample_srt_p = temp_sample_srt
        except Exception:
            sample_srt_p = self.srt_file_path

        self._cleanup_thread()
        self.thread = RenderThread(
            tts_engine=tts_engine,
            srt_subtitles_list=sample_subs,
            srt_file_path=sample_srt_p,
            output_audio=out_audio,
            video_path=video_p,
            output_video=out_sample,
            effects_config=eff_config,
            settings_tab=self.settings_tab,
            orig_vol=orig_vol_float,
            tts_vol=tts_vol_float,
            codec=codec_str,
            preset=preset_str,
            crf=crf_val,
            max_duration=30.0
        )

        self.thread.progress.connect(self.progress_bar.setValue)
        self.thread.log.connect(self.append_log)
        self.thread.finished_status.connect(self.on_render_finished)
        self.thread.start()

    def show_segment_table(self):
        if not self.srt_subtitles_list:
            QMessageBox.warning(self, "Thông báo", "Chưa có thông tin phân đoạn phụ đề.")
            return

        total_lines = len(self.srt_subtitles_list)
        total_duration = self.srt_subtitles_list[-1].end.total_seconds() if self.srt_subtitles_list else 0
        min_str = f"{int(total_duration // 60)} phút {int(total_duration % 60)} giây"

        table_dialog = QDialog(self)
        table_dialog.setWindowTitle("📊 Bảng Thống Kê Phân Đoạn Video")
        table_dialog.resize(520, 380)

        t_layout = QVBoxLayout(table_dialog)
        lbl_summary = QLabel(f"📝 <b>Tổng quan dự án:</b> {total_lines} câu thoại | Thời lượng ước tính: <b>{min_str}</b>")
        lbl_summary.setStyleSheet("color: #38bdf8; font-size: 13px;")
        t_layout.addWidget(lbl_summary)

        txt_info = QTextEdit()
        txt_info.setReadOnly(True)
        txt_info.setStyleSheet("background-color: #020617; color: #f8fafc; font-family: monospace; font-size: 11px;")

        lines = []
        for s in self.srt_subtitles_list[:50]:
            v_name = getattr(s, "voice", "Gốc")
            lines.append(f"[{s.index:03d}] {s.start} -> {s.end} | Giọng: {v_name}\n     Content: {s.content}\n")
        
        if total_lines > 50:
            lines.append(f"... và {total_lines - 50} câu thoại tiếp theo.")

        txt_info.setText("\n".join(lines))
        t_layout.addWidget(txt_info)

        btn_ok = QPushButton("Đóng")
        btn_ok.clicked.connect(table_dialog.accept)
        t_layout.addWidget(btn_ok)

        table_dialog.exec()

    def closeEvent(self, event):
        self.save_current_render_config()
        super().closeEvent(event)
