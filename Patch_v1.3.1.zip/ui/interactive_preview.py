import os
import subprocess
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLabel, QRadioButton, QButtonGroup, QMessageBox)
from PySide6.QtCore import Qt, QPoint, QRect, Signal
from PySide6.QtGui import QPainter, QPen, QColor, QPixmap, QImage, QCursor, QFont, QPainterPath

class FrameDrawingWidget(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = "blur"  # "blur", "logo", "sub"
        
        self.blur_rects = []
        self.logo_rect = None
        self.logo_pixmap = None
        self.logo_scale_pct = 1.0  # 1.0 = 100%
        
        # Subtitle properties & positioning
        self.sub_text = "Demo Phụ Đề Mẫu"
        self.sub_pct_y = 85.0
        self.sub_font = "Bangers"
        self.sub_size = 24
        self.sub_color = QColor(255, 255, 255)
        self.sub_outline = QColor(0, 0, 0)
        self.sub_bold = True
        self.sub_italic = True
        self.sub_shadow = True
        self.sub_outline_width = 3.5
        self.sub_bg_enabled = False
        self.sub_bg_color = QColor(0, 0, 0, 127)

        # Interactive states
        self.selected_target = None
        self.drag_action = None
        
        self.start_point = QPoint()
        self.last_mouse_pos = QPoint()
        self.creating_rect = QRect()
        self.show_snap_guideline = False
        
        self.video_width = 1280
        self.video_height = 720

        self.setMouseTracking(True)

    def set_frame(self, pixmap, video_w, video_h):
        self.setPixmap(pixmap)
        self.setFixedSize(pixmap.size())
        self.video_width = video_w
        self.video_height = video_h
        self.update()

    def set_logo_image(self, logo_path, scale_pct=1.0):
        self.logo_scale_pct = scale_pct
        if logo_path and os.path.exists(logo_path):
            self.logo_pixmap = QPixmap(logo_path)
            if self.logo_pixmap and not self.logo_pixmap.isNull():
                self.recalculate_logo_size()
        else:
            self.logo_pixmap = None
        self.update()

    def update_logo_scale(self, scale_pct):
        self.logo_scale_pct = scale_pct
        if self.logo_pixmap and not self.logo_pixmap.isNull():
            self.recalculate_logo_size()
            self.update()

    def recalculate_logo_size(self):
        if not self.logo_pixmap or self.logo_pixmap.isNull():
            return
            
        base_w = self.logo_pixmap.width()
        base_h = self.logo_pixmap.height()
        ar = base_w / max(1, base_h)
        
        canvas_w = self.width() if self.width() > 0 else 640
        canvas_h = self.height() if self.height() > 0 else 360
        
        disp_w = int(canvas_w * self.logo_scale_pct)
        disp_h = int(disp_w / ar)
        
        if disp_h > canvas_h:
            disp_h = int(canvas_h * self.logo_scale_pct)
            disp_w = int(disp_h * ar)

        disp_w = max(20, disp_w)
        disp_h = max(20, disp_h)

        if not self.logo_rect:
            self.logo_rect = QRect((canvas_w - disp_w) // 2, (canvas_h - disp_h) // 2, disp_w, disp_h)
        else:
            curr_pos = self.logo_rect.topLeft()
            self.logo_rect = QRect(curr_pos.x(), curr_pos.y(), disp_w, disp_h)
            
            if self.logo_rect.right() > canvas_w:
                self.logo_rect.moveLeft(max(0, canvas_w - disp_w))
            if self.logo_rect.bottom() > canvas_h:
                self.logo_rect.moveTop(max(0, canvas_h - disp_h))

    def set_saved_coordinates(self, blurs, logos, sub_pct_y):
        self.sub_pct_y = sub_pct_y
        if not self.pixmap() or self.video_width <= 0 or self.video_height <= 0:
            return

        pix_w = self.pixmap().width()
        pix_h = self.pixmap().height()
        scale_x = pix_w / float(self.video_width)
        scale_y = pix_h / float(self.video_height)

        if blurs:
            self.blur_rects = []
            for b in blurs:
                bx = int(b.get("x", 0) * scale_x)
                by = int(b.get("y", 0) * scale_y)
                bw = int(b.get("w", 50) * scale_x)
                bh = int(b.get("h", 50) * scale_y)
                self.blur_rects.append(QRect(bx, by, bw, bh))

        if logos and len(logos) > 0:
            lg = logos[0]
            lx = int(lg.get("x", 0) * scale_x)
            ly = int(lg.get("y", 0) * scale_y)
            lw = int(lg.get("w", 100) * scale_x)
            lh = int(lg.get("h", 100) * scale_y)
            self.logo_rect = QRect(lx, ly, lw, lh)
        else:
            self.logo_rect = None
            
        self.update()

    def get_sub_rect(self):
        if not self.pixmap():
            return QRect(0, 0, 0, 0)
        w = self.pixmap().width()
        h = self.pixmap().height()
        
        preview_scale = h / max(1, self.video_height)
        preview_font_size = max(11, int(self.sub_size * preview_scale))
        
        sub_h = max(34, int(preview_font_size * 1.5))
        sub_y = int((self.sub_pct_y / 100.0) * h) - sub_h // 2
        sub_y = max(2, min(h - sub_h - 2, sub_y))
        return QRect(10, sub_y, w - 20, sub_h)

    def get_handle_rects(self, rect):
        if not rect:
            return {}
        h = 8
        half = 4
        return {
            "tl": QRect(rect.left() - half, rect.top() - half, h, h),
            "tr": QRect(rect.right() - half, rect.top() - half, h, h),
            "bl": QRect(rect.left() - half, rect.bottom() - half, h, h),
            "br": QRect(rect.right() - half, rect.bottom() - half, h, h),
        }

    def get_target_rect(self, target):
        if not target:
            return None
        t_type, idx = target
        if t_type == 'sub':
            return self.get_sub_rect()
        elif t_type == 'logo':
            return self.logo_rect
        elif t_type == 'blur' and 0 <= idx < len(self.blur_rects):
            return self.blur_rects[idx]
        return None

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            pos = event.position().toPoint()
            self.last_mouse_pos = pos
            
            if self.selected_target and self.selected_target[0] == 'blur':
                curr_rect = self.get_target_rect(self.selected_target)
                if curr_rect:
                    handles = self.get_handle_rects(curr_rect)
                    for h_name, h_rect in handles.items():
                        if h_rect.contains(pos):
                            self.drag_action = f"resize_{h_name}"
                            return

            sub_rect = self.get_sub_rect()
            if sub_rect.contains(pos):
                self.selected_target = ('sub', None)
                self.drag_action = "move"
                self.sub_drag_offset_y = pos.y() - sub_rect.center().y()
                self.update()
                return

            if self.logo_rect and self.logo_rect.contains(pos):
                self.selected_target = ('logo', None)
                self.drag_action = "move"
                self.update()
                return

            for idx in range(len(self.blur_rects) - 1, -1, -1):
                if self.blur_rects[idx].contains(pos):
                    self.selected_target = ('blur', idx)
                    self.drag_action = "move"
                    self.update()
                    return

            self.selected_target = None
            self.start_point = pos
            self.creating_rect = QRect(pos, pos)
            self.drag_action = "create"
            self.update()

    def mouseMoveEvent(self, event):
        pos = event.position().toPoint()
        
        if self.drag_action:
            delta = pos - self.last_mouse_pos
            self.last_mouse_pos = pos

            if self.drag_action == "move" and self.selected_target:
                t_type, idx = self.selected_target
                if t_type == 'sub':
                    pix_h = float(self.pixmap().height()) if self.pixmap() else float(self.height())
                    offset_y = getattr(self, "sub_drag_offset_y", 0)
                    center_y = pos.y() - offset_y
                    self.sub_pct_y = max(2.0, min(98.0, (center_y / pix_h) * 100.0))
                elif t_type == 'logo' and self.logo_rect:
                    self.logo_rect.translate(delta)
                    max_x = max(0, self.width() - self.logo_rect.width())
                    max_y = max(0, self.height() - self.logo_rect.height())
                    clamped_x = max(0, min(max_x, self.logo_rect.x()))
                    clamped_y = max(0, min(max_y, self.logo_rect.y()))
                    self.logo_rect.moveTo(clamped_x, clamped_y)

                    center_x = self.width() // 2
                    if abs(self.logo_rect.center().x() - center_x) < 8:
                        self.logo_rect.moveCenter(QPoint(center_x, self.logo_rect.center().y()))
                        self.show_snap_guideline = True
                    else:
                        self.show_snap_guideline = False
                elif t_type == 'blur' and 0 <= idx < len(self.blur_rects):
                    self.blur_rects[idx].translate(delta)
                    r = self.blur_rects[idx]
                    max_x = max(0, self.width() - r.width())
                    max_y = max(0, self.height() - r.height())
                    clamped_x = max(0, min(max_x, r.x()))
                    clamped_y = max(0, min(max_y, r.y()))
                    self.blur_rects[idx].moveTo(clamped_x, clamped_y)

            elif self.drag_action.startswith("resize_") and self.selected_target and self.selected_target[0] == 'blur':
                h_name = self.drag_action.split("_")[1]
                idx = self.selected_target[1]
                if 0 <= idx < len(self.blur_rects):
                    r = QRect(self.blur_rects[idx])
                    if 't' in h_name:
                        r.setTop(min(r.bottom() - 10, r.top() + delta.y()))
                    if 'b' in h_name:
                        r.setBottom(max(r.top() + 10, r.bottom() + delta.y()))
                    if 'l' in h_name:
                        r.setLeft(min(r.right() - 10, r.left() + delta.x()))
                    if 'r' in h_name:
                        r.setRight(max(r.left() + 10, r.right() + delta.x()))
                    self.blur_rects[idx] = r.normalized()

            elif self.drag_action == "create":
                self.creating_rect = QRect(self.start_point, pos).normalized()

            self.update()
            return

        if self.selected_target and self.selected_target[0] == 'blur':
            curr_rect = self.get_target_rect(self.selected_target)
            if curr_rect:
                handles = self.get_handle_rects(curr_rect)
                for h_name, h_rect in handles.items():
                    if h_rect.contains(pos):
                        if h_name in ["tl", "br"]:
                            self.setCursor(Qt.SizeFDiagCursor)
                        else:
                            self.setCursor(Qt.SizeBDiagCursor)
                        return

        if self.get_sub_rect().contains(pos):
            self.setCursor(Qt.SizeAllCursor)
        elif self.logo_rect and self.logo_rect.contains(pos):
            self.setCursor(Qt.SizeAllCursor)
        else:
            is_over_blur = any(r.contains(pos) for r in self.blur_rects)
            if is_over_blur:
                self.setCursor(Qt.SizeAllCursor)
            else:
                self.setCursor(Qt.CrossCursor if self.mode in ["blur", "logo"] else Qt.ArrowCursor)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            if self.drag_action == "create":
                pix_rect = self.pixmap().rect() if self.pixmap() else self.rect()
                rect = self.creating_rect.intersected(pix_rect)
                if rect.width() > 10 and rect.height() > 10:
                    if self.mode == "blur":
                        self.blur_rects.append(rect)
                        self.selected_target = ('blur', len(self.blur_rects) - 1)
                    elif self.mode == "logo":
                        self.logo_rect = rect
                        self.selected_target = ('logo', None)
                        
            self.drag_action = None
            self.creating_rect = QRect()
            self.show_snap_guideline = False
            self.update()

    def keyPressEvent(self, event):
        key = event.key()
        if key in [Qt.Key_Delete, Qt.Key_Backspace]:
            self.delete_selected()
        elif key in [Qt.Key_Left, Qt.Key_Right, Qt.Key_Up, Qt.Key_Down] and self.selected_target:
            step = 1 if not (event.modifiers() & Qt.ShiftModifier) else 5
            dx = -step if key == Qt.Key_Left else (step if key == Qt.Key_Right else 0)
            dy = -step if key == Qt.Key_Up else (step if key == Qt.Key_Down else 0)
            
            t_type, idx = self.selected_target
            if t_type == 'sub':
                pix_h = self.pixmap().height() if self.pixmap() else self.height()
                self.sub_pct_y = max(2.0, min(98.0, self.sub_pct_y + (dy / pix_h) * 100.0))
            elif t_type == 'logo' and self.logo_rect:
                self.logo_rect.translate(dx, dy)
            elif t_type == 'blur' and 0 <= idx < len(self.blur_rects):
                self.blur_rects[idx].translate(dx, dy)
            self.update()

    def delete_selected(self):
        if self.selected_target:
            t_type, idx = self.selected_target
            if t_type == 'blur' and 0 <= idx < len(self.blur_rects):
                self.blur_rects.pop(idx)
            elif t_type == 'logo':
                self.logo_rect = None
                self.logo_pixmap = None
            self.selected_target = None
            self.update()

    def paintEvent(self, event):
        super().paintEvent(event)
        if not self.pixmap():
            return
            
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Viền ranh giới màn hình Video Preview (Khung chặn giúp căn lề cực dễ)
        painter.setPen(QPen(QColor(56, 189, 248, 180), 2, Qt.DashLine))
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(0, 0, self.width() - 1, self.height() - 1)
        
        if self.show_snap_guideline:
            painter.setPen(QPen(QColor(234, 179, 8), 1, Qt.DashLine))
            center_x = self.width() // 2
            painter.drawLine(center_x, 0, center_x, self.height())

        for idx, rect in enumerate(self.blur_rects):
            is_sel = (self.selected_target == ('blur', idx))
            pen_color = QColor(239, 68, 68) if not is_sel else QColor(255, 255, 255)
            painter.setPen(QPen(pen_color, 2 if not is_sel else 3, Qt.DashLine if not is_sel else Qt.SolidLine))
            painter.setBrush(QColor(239, 68, 68, 80))
            painter.drawRect(rect)
            painter.drawText(rect.topLeft() + QPoint(5, 15), f"BLUR #{idx+1}")
            
            if is_sel:
                self.draw_handles(painter, rect)

        if self.logo_rect:
            is_sel = (self.selected_target == ('logo', None))
            
            if self.logo_pixmap and not self.logo_pixmap.isNull():
                painter.drawPixmap(self.logo_rect, self.logo_pixmap)
            else:
                painter.setBrush(QColor(59, 130, 246, 80))
                painter.drawRect(self.logo_rect)
                painter.drawText(self.logo_rect.topLeft() + QPoint(5, 15), "LOGO/WATERMARK")

            pen_color = QColor(59, 130, 246) if not is_sel else QColor(255, 255, 255)
            painter.setPen(QPen(pen_color, 2 if not is_sel else 3, Qt.SolidLine))
            painter.setBrush(Qt.NoBrush)
            painter.drawRect(self.logo_rect)

        if self.drag_action == "create" and not self.creating_rect.isEmpty():
            painter.setPen(QPen(QColor(255, 255, 255), 1, Qt.DotLine))
            painter.setBrush(QColor(255, 255, 255, 40))
            painter.drawRect(self.creating_rect)

        sub_rect = self.get_sub_rect()
        is_sub_sel = (self.selected_target == ('sub', None))

        if self.sub_bg_enabled:
            painter.setPen(Qt.NoPen)
            painter.setBrush(self.sub_bg_color)
            painter.drawRect(sub_rect)

        preview_scale = self.height() / max(1, self.video_height)
        preview_font_size = max(11, int(self.sub_size * preview_scale))
        font = QFont(self.sub_font, preview_font_size)
        font.setBold(getattr(self, "sub_bold", True))
        font.setItalic(getattr(self, "sub_italic", True))
        painter.setFont(font)
        
        path = QPainterPath()
        metrics = painter.fontMetrics()
        text_w = metrics.horizontalAdvance(self.sub_text)
        text_x = sub_rect.left() + (sub_rect.width() - text_w) // 2
        text_y = sub_rect.center().y() + metrics.height() // 3
        
        path.addText(text_x, text_y, font, self.sub_text)
        
        out_w = float(getattr(self, "sub_outline_width", 3.5))
        pen = QPen(self.sub_outline if self.sub_outline else QColor(0, 0, 0), out_w, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
        painter.setPen(pen)
        painter.drawPath(path)
        painter.fillPath(path, self.sub_color if self.sub_color else QColor(255, 255, 255))

        if is_sub_sel:
            painter.setPen(QPen(QColor(34, 197, 94), 2, Qt.DashLine))
            painter.setBrush(Qt.NoBrush)
            painter.drawRect(sub_rect)

    def draw_handles(self, painter, rect):
        handles = self.get_handle_rects(rect)
        painter.setPen(QPen(QColor(0, 0, 0), 1))
        painter.setBrush(QColor(255, 255, 255))
        for h_rect in handles.values():
            painter.drawRect(h_rect)

    def get_mapped_coordinates(self):
        if not self.pixmap():
            return [], None, self.sub_pct_y

        pix_w = self.pixmap().width()
        pix_h = self.pixmap().height()
        
        scale_x = self.video_width / pix_w
        scale_y = self.video_height / pix_h

        mapped_blurs = []
        for r in self.blur_rects:
            mapped_blurs.append({
                "x": int(r.x() * scale_x),
                "y": int(r.y() * scale_y),
                "w": int(r.width() * scale_x),
                "h": int(r.height() * scale_y)
            })

        mapped_logo = None
        if self.logo_rect:
            mapped_logo = {
                "x": int(self.logo_rect.x() * scale_x),
                "y": int(self.logo_rect.y() * scale_y),
                "w": int(self.logo_rect.width() * scale_x),
                "h": int(self.logo_rect.height() * scale_y)
            }

        return mapped_blurs, mapped_logo, self.sub_pct_y
